import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap, catchError, throwError } from 'rxjs';
import { environment } from '../environments/environment';

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  refreshToken: string;
  user: {
    id: string;
    username: string;
    email: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private currentUser = signal<AuthResponse | null>(null);

  private accessTokenKey = 'access_token';
  private refreshTokenKey = 'refresh_token';

  constructor(private http: HttpClient) {
    this.silentLogin();
  }

  // 🔐 LOGIN
  login(credentials: LoginCredentials): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(
      `${environment.apiBaseUrl}/auth/login`,
      credentials
    ).pipe(
      tap(res => this.handleAuthSuccess(res)),
      catchError(err => {
        return throwError(() => err);
      })
    );
  }

  // 🔄 HANDLE SUCCESS (COMMON FOR LOGIN + REFRESH)
  private handleAuthSuccess(res: AuthResponse): void {
    localStorage.setItem(this.accessTokenKey, res.token);
    localStorage.setItem(this.refreshTokenKey, res.refreshToken);

    this.currentUser.set(res);
  }

  // 🚪 LOGOUT
  logout(): Observable<any> {
    return this.http.post(`${environment.apiBaseUrl}/auth/logout`, {}).pipe(
      tap(() => this.clearAuth()),
      catchError(() => {
        this.clearAuth();
        return throwError(() => new Error('Logout failed'));
      })
    );
  }

  // 🧹 CLEAR AUTH DATA
  private clearAuth(): void {
    localStorage.removeItem(this.accessTokenKey);
    localStorage.removeItem(this.refreshTokenKey);
    this.currentUser.set(null);
  }

  // 🔑 GET ACCESS TOKEN
  getAccessToken(): string | null {
    return localStorage.getItem(this.accessTokenKey);
  }

  // 🔄 REFRESH TOKEN API
  refreshToken(): Observable<AuthResponse> {
    const refreshToken = localStorage.getItem(this.refreshTokenKey);

    if (!refreshToken) {
      return throwError(() => new Error('No refresh token'));
    }

    return this.http.post<AuthResponse>(
      `${environment.apiBaseUrl}/auth/refresh`,
      { refreshToken }
    ).pipe(
      tap(res => this.handleAuthSuccess(res)),
      catchError(err => {
        this.clearAuth();
        return throwError(() => err);
      })
    );
  }

  // 🔁 SILENT LOGIN (AUTO LOGIN ON APP START)
  silentLogin(): void {
    const refreshToken = localStorage.getItem(this.refreshTokenKey);

    if (!refreshToken) return;

    this.refreshToken().subscribe({
      next: () => {
        // silently restored session
      },
      error: () => {
        this.clearAuth();
      }
    });
  }

  // ✅ AUTH CHECK
  isAuthenticated(): boolean {
    return !!this.getAccessToken();
  }

  // 👤 CURRENT USER (SIGNAL)
  getCurrentUser() {
    return this.currentUser();
  }
}