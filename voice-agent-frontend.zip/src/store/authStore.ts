import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User } from '@/types'

const STATIC_USER: User = {
  id: 1,
  email: 'admin@voiceagent.ai',
  username: 'admin',
  full_name: 'Admin User',
  preferred_language: 'en',
  is_active: true,
  created_at: new Date().toISOString(),
}

interface AuthState {
  user: User | null
  token: string | null
  isLoading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  clearError: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isLoading: false,
      error: null,

      login: async (email, password) => {
        set({ isLoading: true, error: null })
        await new Promise((r) => setTimeout(r, 600)) // simulate network

        const validEmail = email.toLowerCase() === 'admin' || email.toLowerCase() === 'admin@voiceagent.ai'
        const validPass = password === 'admin'

        if (validEmail && validPass) {
          set({ user: STATIC_USER, token: 'mock-jwt-token', isLoading: false })
        } else {
          set({ error: 'Invalid credentials. Use admin / admin', isLoading: false })
        }
      },

      logout: () => set({ user: null, token: null }),
      clearError: () => set({ error: null }),
    }),
    {
      name: 'auth-storage',
      partialize: (s) => ({ user: s.user, token: s.token }),
    }
  )
)
