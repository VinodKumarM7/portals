import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { VoiceSession, LiveMessage, LLMProvider, TTSProvider, STTProvider } from '@/types'
import { nanoid } from '@/utils/nanoid'

interface SessionConfig {
  language: string
  llmProvider: LLMProvider
  llmModel: string
  sttProvider: STTProvider
  ttsProvider: TTSProvider
}

interface SessionState {
  sessions: VoiceSession[]
  activeSession: VoiceSession | null
  messages: LiveMessage[]
  isConnected: boolean
  isRecording: boolean
  isThinking: boolean
  statusText: string
  config: SessionConfig
  ws: null

  loadSessions: () => Promise<void>
  startSession: (title?: string) => Promise<void>
  endSession: () => Promise<void>
  deleteSession: (id: number) => Promise<void>
  connectWS: (sessionId: number) => Promise<void>
  disconnectWS: () => void
  sendText: (text: string) => void
  setConfig: (config: Partial<SessionConfig>) => void
  setRecording: (val: boolean) => void
}

let nextId = 100

function makeMockSession(title?: string): VoiceSession {
  return {
    id: ++nextId,
    user_id: 1,
    title: title || `Session ${new Date().toLocaleTimeString()}`,
    language: 'en',
    llm_provider: 'ollama',
    llm_model: 'llama3.1',
    tts_provider: 'edge',
    stt_provider: 'whisper',
    is_active: true,
    started_at: new Date().toISOString(),
    ended_at: null,
  }
}

const MOCK_REPLIES: Record<string, string> = {
  default: "I'm your AI voice assistant. Once you connect a real LLM (Ollama, OpenAI, or Anthropic), I'll respond intelligently. For now, this is a mock response.",
  hello: "Hello! Great to hear from you. I'm ready to assist when you integrate your preferred LLM provider.",
  hi: "Hi there! This is a mock response. Integrate Ollama or OpenAI in the backend to get real AI replies.",
  help: "I can help with conversations, questions, and tasks once connected to an LLM. Set up the FastAPI backend with Ollama to get started!",
  test: "Test received! The voice pipeline is wired up. Add Whisper for STT, Ollama for LLM, and Edge TTS for speech output.",
}

function getMockReply(text: string): string {
  const lower = text.toLowerCase().trim()
  for (const [key, val] of Object.entries(MOCK_REPLIES)) {
    if (lower.includes(key)) return val
  }
  return MOCK_REPLIES.default
}

export const useSessionStore = create<SessionState>()(
  persist(
    (set, get) => ({
      sessions: [],
      activeSession: null,
      messages: [],
      isConnected: false,
      isRecording: false,
      isThinking: false,
      statusText: 'Ready (Mock Mode)',
      ws: null,
      config: {
        language: 'en',
        llmProvider: 'ollama',
        llmModel: 'llama3.1',
        sttProvider: 'whisper',
        ttsProvider: 'edge',
      },

      loadSessions: async () => {
        // sessions already in persisted store — nothing to fetch
      },

      startSession: async (title) => {
        const session = makeMockSession(title)
        set((s) => ({
          activeSession: session,
          sessions: [session, ...s.sessions],
          messages: [],
          isConnected: true,
          statusText: 'Connected (Mock Mode)',
        }))
      },

      endSession: async () => {
        const { activeSession } = get()
        if (!activeSession) return
        set((s) => ({
          activeSession: null,
          isConnected: false,
          sessions: s.sessions.map((ss) =>
            ss.id === activeSession.id ? { ...ss, is_active: false, ended_at: new Date().toISOString() } : ss
          ),
        }))
      },

      deleteSession: async (id) => {
        set((s) => ({ sessions: s.sessions.filter((ss) => ss.id !== id) }))
      },

      connectWS: async (sessionId) => {
        set({ isConnected: true, statusText: 'Connected (Mock Mode)' })
      },

      disconnectWS: () => set({ isConnected: false, ws: null }),

      sendText: (text) => {
        if (!text.trim()) return
        const userId = nanoid()
        // Add user message
        set((s) => ({
          messages: [
            ...s.messages,
            { id: userId, speaker: 'user', text, language: get().config.language, timestamp: new Date() },
          ],
          isThinking: true,
          statusText: 'Thinking...',
        }))

        // Simulate LLM response delay
        setTimeout(() => {
          const reply = getMockReply(text)
          set((s) => ({
            messages: [
              ...s.messages,
              { id: nanoid(), speaker: 'assistant', text: reply, language: get().config.language, timestamp: new Date() },
            ],
            isThinking: false,
            statusText: 'Ready (Mock Mode)',
          }))
        }, 1000 + Math.random() * 800)
      },

      setConfig: (config) => set((s) => ({ config: { ...s.config, ...config } })),
      setRecording: (val) => set({ isRecording: val }),
    }),
    {
      name: 'session-storage',
      partialize: (s) => ({ sessions: s.sessions }),
    }
  )
)
