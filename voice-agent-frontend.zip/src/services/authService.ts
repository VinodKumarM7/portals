// Static mock auth — no backend
export const authService = {}
