import type { LiveMessage } from '@/types'

export const sessionService = {}

export const transcriptService = {
  // Export transcript as downloadable .txt in mock mode (no backend needed)
  exportAsText(messages: LiveMessage[], sessionTitle: string): void {
    const lines = messages.map((m) => {
      const ts = m.timestamp.toLocaleTimeString()
      const speaker = m.speaker === 'user' ? 'You' : 'Assistant'
      return `[${ts}] ${speaker} (${m.language}): ${m.text}`
    })
    const content = `Transcript: ${sessionTitle}\n${'─'.repeat(50)}\n\n${lines.join('\n')}`
    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `transcript-${sessionTitle.replace(/\s+/g, '-')}.txt`
    a.click()
    URL.revokeObjectURL(url)
  },
}
