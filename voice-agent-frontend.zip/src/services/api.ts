// Mock API — no backend needed
export default {}
