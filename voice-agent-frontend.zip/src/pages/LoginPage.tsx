import { useState, FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Mic, Info } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import styles from './AuthPage.module.css'

export default function LoginPage() {
  const [email, setEmail] = useState('admin')
  const [password, setPassword] = useState('admin')
  const { login, isLoading, error, clearError } = useAuthStore()
  const navigate = useNavigate()

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    clearError()
    await login(email, password)
    if (useAuthStore.getState().token) navigate('/')
  }

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <div className={styles.logo}>
          <Mic size={28} />
        </div>
        <h1 className={styles.title}>VoiceAgent</h1>
        <p className={styles.subtitle}>Sign in to your account</p>

        <div className={styles.hint}>
          <Info size={13} />
          <span>Demo credentials: <strong>admin</strong> / <strong>admin</strong></span>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.field}>
            <label>Username or Email</label>
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin"
              required
              autoFocus
            />
          </div>
          <div className={styles.field}>
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />
          </div>

          {error && <p className={styles.error}>{error}</p>}

          <button type="submit" className={styles.btn} disabled={isLoading}>
            {isLoading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className={styles.footer}>
          No account? <Link to="/register">Create one</Link>
        </p>
      </div>
    </div>
  )
}
