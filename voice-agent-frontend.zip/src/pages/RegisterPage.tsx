import { useState, FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Mic, Info } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import styles from './AuthPage.module.css'

export default function RegisterPage() {
  const [form, setForm] = useState({ email: '', username: '', fullName: '', password: '' })
  const navigate = useNavigate()

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    // In mock mode, registration just redirects to login
    navigate('/login')
  }

  const set = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [field]: e.target.value }))

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <div className={styles.logo}>
          <Mic size={28} />
        </div>
        <h1 className={styles.title}>VoiceAgent</h1>
        <p className={styles.subtitle}>Create your account</p>

        <div className={styles.hint}>
          <Info size={13} />
          <span>Mock mode — use <strong>admin</strong> / <strong>admin</strong> to sign in</span>
        </div>

        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.field}>
            <label>Full Name</label>
            <input type="text" value={form.fullName} onChange={set('fullName')} placeholder="Your name" />
          </div>
          <div className={styles.field}>
            <label>Username</label>
            <input type="text" value={form.username} onChange={set('username')} placeholder="username" required />
          </div>
          <div className={styles.field}>
            <label>Email</label>
            <input type="email" value={form.email} onChange={set('email')} placeholder="you@example.com" required />
          </div>
          <div className={styles.field}>
            <label>Password</label>
            <input type="password" value={form.password} onChange={set('password')} placeholder="••••••••" required minLength={6} />
          </div>

          <button type="submit" className={styles.btn}>
            Create account (Mock)
          </button>
        </form>

        <p className={styles.footer}>
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  )
}
