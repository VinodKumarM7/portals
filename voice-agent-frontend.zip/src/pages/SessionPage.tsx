import { useEffect, useRef, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  Mic, MicOff, Send, ArrowLeft, Settings,
  Download, StopCircle, Loader2, Bot
} from 'lucide-react'
import { useSessionStore } from '@/store/sessionStore'
import { useAudioRecorder } from '@/hooks/useAudioRecorder'
import { SUPPORTED_LANGUAGES } from '@/types'
import { transcriptService } from '@/services/sessionService'
import { format } from 'date-fns'
import styles from './SessionPage.module.css'

export default function SessionPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const sessionId = Number(id)

  const {
    activeSession, messages, isConnected, isRecording,
    isThinking, statusText, config,
    connectWS, endSession, setConfig, sendText,
  } = useSessionStore()

  const { toggleRecording } = useAudioRecorder()

  const [textInput, setTextInput] = useState('')
  const [showSettings, setShowSettings] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  // Connect (mock) if not already
  useEffect(() => {
    if (!isConnected && sessionId) connectWS(sessionId)
  }, [sessionId, isConnected, connectWS])

  // Auto-scroll on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isThinking])

  function handleSendText() {
    if (!textInput.trim()) return
    sendText(textInput)
    setTextInput('')
  }

  async function handleEnd() {
    await endSession()
    navigate('/')
  }

  function handleExport() {
    const title = activeSession?.title || `Session-${sessionId}`
    transcriptService.exportAsText(messages, title)
  }

  return (
    <div className={styles.page}>
      {/* ── Header ── */}
      <header className={styles.header}>
        <button className={styles.iconBtn} onClick={() => navigate('/')} title="Back">
          <ArrowLeft size={18} />
        </button>

        <div className={styles.headerInfo}>
          <span className={styles.sessionName}>
            {activeSession?.title || `Session ${sessionId}`}
          </span>
          <span className={`${styles.status} ${isConnected ? styles.statusOnline : ''}`}>
            {isConnected ? '● Mock Mode' : '○ Disconnected'}
          </span>
        </div>

        <div className={styles.headerActions}>
          <button
            className={styles.iconBtn}
            onClick={handleExport}
            title="Export transcript"
            disabled={messages.length === 0}
          >
            <Download size={16} />
          </button>
          <button
            className={styles.iconBtn}
            onClick={() => setShowSettings(!showSettings)}
            title="Settings"
          >
            <Settings size={16} />
          </button>
          <button className={styles.endBtn} onClick={handleEnd}>
            <StopCircle size={14} />
            End
          </button>
        </div>
      </header>

      <div className={styles.body}>

        {/* ── Settings Panel ── */}
        {showSettings && (
          <aside className={styles.settingsPanel}>
            <h3>Session Config</h3>

            <label>Language
              <select value={config.language} onChange={(e) => setConfig({ language: e.target.value })}>
                <option value="auto">Auto-detect</option>
                {SUPPORTED_LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code}>{l.label}</option>
                ))}
              </select>
            </label>

            <label>LLM Provider
              <select value={config.llmProvider} onChange={(e) => setConfig({ llmProvider: e.target.value as never })}>
                <option value="ollama">Ollama (local)</option>
                <option value="openai">OpenAI</option>
                <option value="anthropic">Anthropic</option>
              </select>
            </label>

            <label>Model
              <input
                type="text"
                value={config.llmModel}
                onChange={(e) => setConfig({ llmModel: e.target.value })}
                placeholder="e.g. llama3.1"
              />
            </label>

            <label>STT Provider
              <select value={config.sttProvider} onChange={(e) => setConfig({ sttProvider: e.target.value as never })}>
                <option value="whisper">Whisper (local)</option>
                <option value="deepgram">Deepgram</option>
                <option value="azure">Azure</option>
              </select>
            </label>

            <label>TTS Provider
              <select value={config.ttsProvider} onChange={(e) => setConfig({ ttsProvider: e.target.value as never })}>
                <option value="edge">Edge TTS (free)</option>
                <option value="coqui">Coqui (local)</option>
                <option value="elevenlabs">ElevenLabs</option>
              </select>
            </label>

            <div className={styles.mockBadge}>
              ⚠️ Mock mode active. Connect the FastAPI backend to enable real AI responses.
            </div>
          </aside>
        )}

        {/* ── Transcript ── */}
        <main className={styles.transcript}>
          {messages.length === 0 && (
            <div className={styles.emptyState}>
              <Bot size={40} />
              <h3>Ready to chat</h3>
              <p>Type a message below or hold the mic button to speak.<br />
              Connect the FastAPI backend for real AI + voice.</p>
            </div>
          )}

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`${styles.message} ${msg.speaker === 'user' ? styles.userMsg : styles.aiMsg} fade-up`}
            >
              <div className={styles.msgMeta}>
                <span className={styles.msgSpeaker}>
                  {msg.speaker === 'user' ? 'You' : 'Assistant'}
                </span>
                <span className={styles.msgLang}>{msg.language}</span>
                <span className={styles.msgTime}>
                  {format(msg.timestamp, 'HH:mm:ss')}
                </span>
              </div>
              <p className={styles.msgText}>{msg.text}</p>
            </div>
          ))}

          {isThinking && (
            <div className={`${styles.message} ${styles.aiMsg} fade-up`}>
              <div className={styles.msgMeta}>
                <span className={styles.msgSpeaker}>Assistant</span>
              </div>
              <div className={styles.thinking}>
                <span /><span /><span />
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </main>
      </div>

      {/* ── Input Bar ── */}
      <footer className={styles.inputBar}>
        <div className={styles.statusBar}>
          {isThinking && <Loader2 size={12} className={styles.spinner} />}
          <span>{statusText}</span>
        </div>

        <div className={styles.inputRow}>
          <button
            className={`${styles.micBtn} ${isRecording ? styles.micActive : ''}`}
            onMouseDown={() => !isRecording && toggleRecording(false)}
            onMouseUp={() => isRecording && toggleRecording(true)}
            onTouchStart={(e) => { e.preventDefault(); !isRecording && toggleRecording(false) }}
            onTouchEnd={(e) => { e.preventDefault(); isRecording && toggleRecording(true) }}
            title={isRecording ? 'Release to send' : 'Hold to speak'}
            disabled={!isConnected}
          >
            {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
            {isRecording && <span className={styles.pulseRing} />}
          </button>

          <input
            className={styles.textInput}
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendText()}
            placeholder="Type a message or hold mic to speak…"
            disabled={!isConnected}
            autoFocus
          />

          <button
            className={styles.sendBtn}
            onClick={handleSendText}
            disabled={!textInput.trim() || !isConnected}
          >
            <Send size={16} />
          </button>
        </div>
      </footer>
    </div>
  )
}
