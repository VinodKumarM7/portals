import { useCallback } from 'react'

// In mock mode TTS audio is a stub — no-op player
export function useAudioPlayer() {
  const enqueueAudio = useCallback((_base64: string) => {
    // Will play real TTS audio once backend is connected
  }, [])

  const clearQueue = useCallback(() => {}, [])

  return { enqueueAudio, clearQueue }
}
