import { useRef, useCallback } from 'react'
import { useSessionStore } from '@/store/sessionStore'

export function useAudioRecorder() {
  const mediaRecorder = useRef<MediaRecorder | null>(null)
  const { setRecording, sendText } = useSessionStore()

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' })
      const chunks: Blob[] = []

      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data) }

      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop())
        // Mock mode: simulate STT with placeholder
        sendText('[🎙️ Voice input received — connect Whisper STT in backend to transcribe real audio]')
      }

      recorder.start()
      mediaRecorder.current = recorder
      setRecording(true)
    } catch {
      // Mic not available
      sendText('[🎙️ Mic not available — type a message instead]')
      setRecording(false)
    }
  }, [sendText, setRecording])

  const stopRecording = useCallback(() => {
    if (mediaRecorder.current?.state === 'recording') {
      mediaRecorder.current.stop()
    }
    mediaRecorder.current = null
    setRecording(false)
  }, [setRecording])

  const toggleRecording = useCallback(
    (isRecording: boolean) => {
      if (isRecording) stopRecording()
      else startRecording()
    },
    [startRecording, stopRecording]
  )

  return { startRecording, stopRecording, toggleRecording }
}
