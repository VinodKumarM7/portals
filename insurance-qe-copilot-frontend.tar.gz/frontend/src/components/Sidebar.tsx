import type { AgentType } from '../types';
import { AGENT_META } from '../utils/agents';

interface Props {
  onExampleClick: (text: string) => void;
  activeAgent?: AgentType;
}

export function Sidebar({ onExampleClick, activeAgent }: Props) {
  const agents = Object.entries(AGENT_META) as [AgentType, typeof AGENT_META[AgentType]][];

  return (
    <aside style={{
      width: 280,
      flexShrink: 0,
      background: '#0f172a',
      borderRight: '1px solid #1e293b',
      overflowY: 'auto',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Logo */}
      <div style={{
        padding: '24px 20px 20px',
        borderBottom: '1px solid #1e293b',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36,
            height: 36,
            borderRadius: 10,
            background: 'linear-gradient(135deg, #1d4ed8, #7c3aed)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 18,
          }}>
            🛡️
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f1f5f9', letterSpacing: '-0.01em' }}>
              QE Copilot
            </div>
            <div style={{ fontSize: 10, color: '#475569', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
              Insurance · AI-Powered
            </div>
          </div>
        </div>
      </div>

      {/* Agents */}
      <div style={{ padding: '16px 12px', flex: 1 }}>
        <div style={{
          fontSize: 10,
          fontWeight: 600,
          color: '#475569',
          letterSpacing: '0.1em',
          textTransform: 'uppercase',
          marginBottom: 8,
          paddingLeft: 8,
        }}>
          Agents
        </div>

        {agents.map(([key, meta]) => {
          const isActive = activeAgent === key;
          return (
            <div key={key} style={{
              marginBottom: 4,
              borderRadius: 10,
              border: isActive ? `1px solid ${meta.color}40` : '1px solid transparent',
              background: isActive ? `${meta.color}10` : 'transparent',
              overflow: 'hidden',
              transition: 'all 0.15s ease',
            }}>
              {/* Agent header */}
              <div style={{
                padding: '10px 12px',
                display: 'flex',
                alignItems: 'center',
                gap: 8,
              }}>
                <span style={{ fontSize: 16 }}>{meta.icon}</span>
                <div>
                  <div style={{
                    fontSize: 12,
                    fontWeight: 600,
                    color: isActive ? meta.color : '#94a3b8',
                  }}>
                    {meta.label}
                  </div>
                  <div style={{ fontSize: 10, color: '#475569', lineHeight: 1.4, marginTop: 1 }}>
                    {meta.description}
                  </div>
                </div>
              </div>

              {/* Examples */}
              <div style={{ paddingBottom: 8, paddingLeft: 12, paddingRight: 12 }}>
                {meta.examples.map((ex, i) => (
                  <button
                    key={i}
                    onClick={() => onExampleClick(ex)}
                    style={{
                      display: 'block',
                      width: '100%',
                      textAlign: 'left',
                      background: 'transparent',
                      border: 'none',
                      cursor: 'pointer',
                      padding: '5px 8px',
                      borderRadius: 6,
                      fontSize: 11,
                      color: '#64748b',
                      lineHeight: 1.4,
                      transition: 'all 0.1s',
                      marginBottom: 2,
                    }}
                    onMouseEnter={e => {
                      (e.target as HTMLElement).style.background = `${meta.color}15`;
                      (e.target as HTMLElement).style.color = meta.color;
                    }}
                    onMouseLeave={e => {
                      (e.target as HTMLElement).style.background = 'transparent';
                      (e.target as HTMLElement).style.color = '#64748b';
                    }}
                  >
                    ↗ {ex}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{
        padding: '12px 20px',
        borderTop: '1px solid #1e293b',
        fontSize: 10,
        color: '#334155',
        lineHeight: 1.6,
      }}>
        <div style={{ marginBottom: 2 }}>Backend: <span style={{ color: '#475569' }}>FastAPI + LangGraph</span></div>
        <div>Vector DB: <span style={{ color: '#475569' }}>Qdrant (local)</span></div>
      </div>
    </aside>
  );
}
