import { useState, useRef } from 'react';
import type { KeyboardEvent } from 'react';
import { Send, Trash2 } from 'lucide-react';

interface Props {
  onSend: (text: string) => void;
  onClear: () => void;
  loading: boolean;
  hasMessages: boolean;
}

export function ChatInput({ onSend, onClear, loading, hasMessages }: Props) {
  const [value, setValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (!value.trim() || loading) return;
    onSend(value);
    setValue('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInput = () => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 160) + 'px';
  };

  return (
    <div style={{
      padding: '16px 20px 20px',
      borderTop: '1px solid #1e293b',
      background: '#0f172a',
    }}>
      {/* Hint */}
      <div style={{
        fontSize: 10,
        color: '#334155',
        marginBottom: 8,
        textAlign: 'center',
        letterSpacing: '0.04em',
      }}>
        Shift+Enter for new line · Enter to send
      </div>

      <div style={{
        display: 'flex',
        gap: 8,
        alignItems: 'flex-end',
        background: '#1e293b',
        border: '1px solid #334155',
        borderRadius: 14,
        padding: '8px 8px 8px 16px',
        transition: 'border-color 0.15s',
      }}
        onFocus={() => {}}
      >
        <textarea
          ref={textareaRef}
          value={value}
          onChange={e => setValue(e.target.value)}
          onInput={handleInput}
          onKeyDown={handleKeyDown}
          placeholder="Ask the QE Copilot anything about insurance testing…"
          rows={1}
          disabled={loading}
          style={{
            flex: 1,
            background: 'transparent',
            border: 'none',
            outline: 'none',
            resize: 'none',
            fontSize: 13,
            color: '#e2e8f0',
            lineHeight: 1.6,
            fontFamily: 'inherit',
            minHeight: 22,
            maxHeight: 160,
          }}
        />

        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {hasMessages && (
            <button
              onClick={onClear}
              title="Clear chat"
              style={{
                width: 32,
                height: 32,
                borderRadius: 8,
                border: 'none',
                background: 'transparent',
                cursor: 'pointer',
                color: '#475569',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.15s',
              }}
              onMouseEnter={e => (e.currentTarget.style.color = '#ef4444')}
              onMouseLeave={e => (e.currentTarget.style.color = '#475569')}
            >
              <Trash2 size={14} />
            </button>
          )}

          <button
            onClick={handleSend}
            disabled={!value.trim() || loading}
            style={{
              width: 34,
              height: 34,
              borderRadius: 10,
              border: 'none',
              background: value.trim() && !loading
                ? 'linear-gradient(135deg, #1d4ed8, #7c3aed)'
                : '#1e293b',
              cursor: value.trim() && !loading ? 'pointer' : 'not-allowed',
              color: value.trim() && !loading ? '#fff' : '#334155',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.15s',
              boxShadow: value.trim() && !loading ? '0 2px 8px rgba(29,78,216,0.4)' : 'none',
            }}
          >
            {loading ? (
              <div style={{
                width: 14,
                height: 14,
                border: '2px solid #334155',
                borderTop: '2px solid #60a5fa',
                borderRadius: '50%',
                animation: 'spin 0.8s linear infinite',
              }} />
            ) : (
              <Send size={14} />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
