import type { AgentType, AgentMeta } from '../types';

export const AGENT_META: Record<AgentType, AgentMeta> = {
  requirements: {
    label: 'Requirements Agent',
    icon: '📋',
    color: '#3b82f6',
    border: '#1d4ed8',
    description: 'Extracts & analyzes testable requirements from feature descriptions',
    examples: [
      'Analyze requirements for the claims submission module',
      'Extract testable requirements from: Policy renewal must notify users 30 days before expiry',
      'What are the edge cases in the premium calculation feature?',
    ],
  },
  test: {
    label: 'Test Agent',
    icon: '🧪',
    color: '#8b5cf6',
    border: '#6d28d9',
    description: 'Generates structured test cases with steps, preconditions and expected results',
    examples: [
      'Generate test cases for user login with 2FA in an insurance portal',
      'Write BDD scenarios for policy renewal workflow',
      'Create test cases for the claims adjudication engine',
    ],
  },
  coverage: {
    label: 'Coverage Agent',
    icon: '📊',
    color: '#10b981',
    border: '#047857',
    description: 'Identifies gaps in test coverage including regulatory and boundary scenarios',
    examples: [
      'Identify coverage gaps for the underwriting module',
      'What boundary value tests are missing for premium calculation?',
      'Check regulatory coverage for GDPR in our data handling tests',
    ],
  },
  defect: {
    label: 'Defect Agent',
    icon: '🐛',
    color: '#ef4444',
    border: '#b91c1c',
    description: 'Classifies bugs by severity and suggests root cause and regression tests',
    examples: [
      'Classify: Policy PDF generates incorrect deductible amount for multi-car plans',
      'Triage this defect: Login fails intermittently for agents in IE11',
      'What regression tests should cover the claims payment defect?',
    ],
  },
  review: {
    label: 'Review Agent',
    icon: '🔍',
    color: '#f59e0b',
    border: '#b45309',
    description: 'Reviews test artifacts for quality, completeness and insurance compliance',
    examples: [
      'Review these test cases for the new motor insurance product',
      'Are our smoke tests covering the critical payment paths?',
      'Audit our test suite for state insurance compliance gaps',
    ],
  },
};
