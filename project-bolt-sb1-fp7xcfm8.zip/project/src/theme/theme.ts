import { createTheme, type Theme } from '@mui/material/styles';

const brand = {
  primary: '#C5281C',
  secondary: '#FFFFFF',
  accent: '#2E2E2E',
  background: '#F8F9FA',
  success: '#28A745',
  warning: '#FFC107',
  error: '#C5281C',
  info: '#1A73E8',
};

export const lightTheme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: brand.primary, dark: '#9E2016', light: '#E05548' },
    secondary: { main: brand.accent, dark: '#1A1A1A', light: '#4A4A4A' },
    background: { default: brand.background, paper: '#FFFFFF' },
    success: { main: brand.success },
    warning: { main: brand.warning },
    error: { main: brand.error },
    info: { main: brand.info },
    text: { primary: brand.accent, secondary: '#6C757D' },
    divider: 'rgba(0,0,0,0.08)',
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h4: { fontWeight: 700, letterSpacing: '-0.02em' },
    h5: { fontWeight: 600, letterSpacing: '-0.01em' },
    h6: { fontWeight: 600 },
    subtitle1: { fontWeight: 500 },
    body2: { color: '#6C757D' },
  },
  shape: { borderRadius: 12 },
  shadows: [
    'none',
    '0 1px 3px rgba(0,0,0,0.04)',
    '0 2px 8px rgba(0,0,0,0.06)',
    '0 4px 16px rgba(0,0,0,0.08)',
    '0 8px 24px rgba(0,0,0,0.10)',
    '0 12px 32px rgba(0,0,0,0.12)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
    '0 16px 48px rgba(0,0,0,0.14)',
  ] as unknown as Theme['shadows'],
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 600,
          borderRadius: 8,
          padding: '8px 20px',
          transition: 'all 0.2s ease',
        },
        contained: {
          boxShadow: '0 2px 8px rgba(197,40,28,0.25)',
          '&:hover': { boxShadow: '0 4px 16px rgba(197,40,28,0.35)' },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backdropFilter: 'blur(20px)',
          border: '1px solid rgba(255,255,255,0.18)',
          transition: 'all 0.3s cubic-bezier(0.4,0,0.2,1)',
          '&:hover': {
            transform: 'translateY(-2px)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.08)',
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 500, borderRadius: 8 },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          borderRight: 'none',
          boxShadow: '2px 0 12px rgba(0,0,0,0.04)',
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: { borderBottom: '1px solid rgba(0,0,0,0.06)' },
        head: { fontWeight: 600, color: '#6C757D', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' },
      },
    },
  },
});

export const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: { main: '#E05548', dark: brand.primary, light: '#F07868' },
    secondary: { main: '#B0B0B0', dark: '#808080', light: '#D0D0D0' },
    background: { default: '#121212', paper: '#1E1E1E' },
    success: { main: '#4CAF50' },
    warning: { main: '#FFB300' },
    error: { main: '#EF5350' },
    info: { main: '#42A5F5' },
    text: { primary: '#E0E0E0', secondary: '#9E9E9E' },
    divider: 'rgba(255,255,255,0.08)',
  },
  typography: lightTheme.typography,
  shape: lightTheme.shape,
  shadows: Array(25).fill('none') as unknown as Theme['shadows'],
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: 'none',
          fontWeight: 600,
          borderRadius: 8,
          padding: '8px 20px',
          transition: 'all 0.2s ease',
        },
        contained: {
          boxShadow: '0 2px 8px rgba(224,85,72,0.3)',
          '&:hover': { boxShadow: '0 4px 16px rgba(224,85,72,0.4)' },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backdropFilter: 'blur(20px)',
          background: 'rgba(30,30,30,0.8)',
          border: '1px solid rgba(255,255,255,0.06)',
          transition: 'all 0.3s cubic-bezier(0.4,0,0.2,1)',
          '&:hover': {
            transform: 'translateY(-2px)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { fontWeight: 500, borderRadius: 8 },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          borderRight: 'none',
          background: '#1A1A1A',
          boxShadow: '2px 0 12px rgba(0,0,0,0.2)',
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: { borderBottom: '1px solid rgba(255,255,255,0.06)' },
        head: { fontWeight: 600, color: '#9E9E9E', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em' },
      },
    },
  },
});
