import type { KPIMetric, TestExecution, Defect, TestCase, ChatMessage, AIInsight, SprintMetric, TrendData } from '../types';

export const kpiMetrics: KPIMetric[] = [
  { id: '1', title: 'Total Test Cases', value: 2847, change: 12.5, changeLabel: 'vs last sprint', icon: 'TestTube', color: '#1A73E8' },
  { id: '2', title: 'Pass Rate', value: '87.3%', change: 3.2, changeLabel: 'vs last sprint', icon: 'CheckCircle', color: '#28A745' },
  { id: '3', title: 'Open Defects', value: 34, change: -8.1, changeLabel: 'vs last week', icon: 'BugReport', color: '#C5281C' },
  { id: '4', title: 'Automation Coverage', value: '72.1%', change: 5.4, changeLabel: 'vs last month', icon: 'SmartToy', color: '#FFC107' },
];

export const testExecutions: TestExecution[] = [
  { id: 'TE-001', testCaseId: 'TC-1024', testName: 'Login with valid credentials', suite: 'Authentication', status: 'passed', duration: '2.3s', executedBy: 'Sarah Chen', executedAt: '2026-06-17T09:15:00Z', environment: 'Staging', buildNumber: 'B-4.2.1' },
  { id: 'TE-002', testCaseId: 'TC-1025', testName: 'Password reset flow', suite: 'Authentication', status: 'failed', duration: '5.1s', executedBy: 'James Wilson', executedAt: '2026-06-17T09:20:00Z', environment: 'Staging', buildNumber: 'B-4.2.1' },
  { id: 'TE-003', testCaseId: 'TC-2048', testName: 'Policy creation end-to-end', suite: 'Policy Management', status: 'running', duration: '-', executedBy: 'Auto Runner', executedAt: '2026-06-17T09:25:00Z', environment: 'QA', buildNumber: 'B-4.2.2' },
  { id: 'TE-004', testCaseId: 'TC-2049', testName: 'Claim submission validation', suite: 'Claims', status: 'passed', duration: '3.8s', executedBy: 'Maria Garcia', executedAt: '2026-06-17T09:30:00Z', environment: 'Staging', buildNumber: 'B-4.2.1' },
  { id: 'TE-005', testCaseId: 'TC-3072', testName: 'Premium calculation engine', suite: 'Rating Engine', status: 'blocked', duration: '-', executedBy: 'Auto Runner', executedAt: '2026-06-17T09:35:00Z', environment: 'QA', buildNumber: 'B-4.2.2' },
  { id: 'TE-006', testCaseId: 'TC-3073', testName: 'Document upload verification', suite: 'Document Management', status: 'passed', duration: '4.2s', executedBy: 'Liam O\'Brien', executedAt: '2026-06-17T09:40:00Z', environment: 'Staging', buildNumber: 'B-4.2.1' },
  { id: 'TE-007', testCaseId: 'TC-4096', testName: 'Customer search and filter', suite: 'Customer Portal', status: 'passed', duration: '1.9s', executedBy: 'Sarah Chen', executedAt: '2026-06-17T09:45:00Z', environment: 'Staging', buildNumber: 'B-4.2.1' },
  { id: 'TE-008', testCaseId: 'TC-4097', testName: 'Batch payment processing', suite: 'Payments', status: 'failed', duration: '8.7s', executedBy: 'Auto Runner', executedAt: '2026-06-17T09:50:00Z', environment: 'QA', buildNumber: 'B-4.2.2' },
  { id: 'TE-009', testCaseId: 'TC-5120', testName: 'Report generation stress test', suite: 'Reporting', status: 'skipped', duration: '-', executedBy: 'Auto Runner', executedAt: '2026-06-17T09:55:00Z', environment: 'Perf', buildNumber: 'B-4.2.2' },
  { id: 'TE-010', testCaseId: 'TC-5121', testName: 'API rate limiting validation', suite: 'API Gateway', status: 'passed', duration: '6.4s', executedBy: 'James Wilson', executedAt: '2026-06-17T10:00:00Z', environment: 'Staging', buildNumber: 'B-4.2.1' },
];

export const defects: Defect[] = [
  { id: 'DEF-1042', title: 'Login fails with special characters in password', severity: 'critical', priority: 'P1', status: 'in-progress', assignee: 'Alex Kim', reporter: 'Sarah Chen', createdAt: '2026-06-15T08:00:00Z', updatedAt: '2026-06-17T07:00:00Z', sprint: 'Sprint 24', module: 'Authentication' },
  { id: 'DEF-1043', title: 'Policy document preview not loading', severity: 'high', priority: 'P2', status: 'open', assignee: 'Unassigned', reporter: 'James Wilson', createdAt: '2026-06-16T10:30:00Z', updatedAt: '2026-06-16T10:30:00Z', sprint: 'Sprint 24', module: 'Policy Management' },
  { id: 'DEF-1044', title: 'Incorrect premium for multi-risk policies', severity: 'critical', priority: 'P1', status: 'open', assignee: 'Maria Garcia', reporter: 'Auto QA', createdAt: '2026-06-16T14:00:00Z', updatedAt: '2026-06-17T06:00:00Z', sprint: 'Sprint 24', module: 'Rating Engine' },
  { id: 'DEF-1045', title: 'Claim status email not triggered', severity: 'medium', priority: 'P3', status: 'resolved', assignee: 'Liam O\'Brien', reporter: 'Maria Garcia', createdAt: '2026-06-14T09:00:00Z', updatedAt: '2026-06-16T16:00:00Z', sprint: 'Sprint 23', module: 'Claims' },
  { id: 'DEF-1046', title: 'Dashboard charts not rendering in Safari', severity: 'low', priority: 'P4', status: 'closed', assignee: 'Alex Kim', reporter: 'James Wilson', createdAt: '2026-06-12T11:00:00Z', updatedAt: '2026-06-15T14:00:00Z', sprint: 'Sprint 23', module: 'Reporting' },
  { id: 'DEF-1047', title: 'Batch upload timeout for >500 documents', severity: 'high', priority: 'P2', status: 'in-progress', assignee: 'Liam O\'Brien', reporter: 'Auto QA', createdAt: '2026-06-16T16:00:00Z', updatedAt: '2026-06-17T08:00:00Z', sprint: 'Sprint 24', module: 'Document Management' },
  { id: 'DEF-1048', title: 'Session expires during long form entry', severity: 'medium', priority: 'P3', status: 'reopened', assignee: 'Unassigned', reporter: 'Sarah Chen', createdAt: '2026-06-10T08:00:00Z', updatedAt: '2026-06-17T09:00:00Z', sprint: 'Sprint 24', module: 'Authentication' },
  { id: 'DEF-1049', title: 'Payment retry logic fails silently', severity: 'high', priority: 'P2', status: 'open', assignee: 'Maria Garcia', reporter: 'Auto QA', createdAt: '2026-06-17T07:00:00Z', updatedAt: '2026-06-17T07:00:00Z', sprint: 'Sprint 24', module: 'Payments' },
];

export const testCases: TestCase[] = [
  { id: 'TC-1024', title: 'Login with valid credentials', module: 'Authentication', priority: 'critical', type: 'functional', status: 'active', steps: 5, lastRun: '2026-06-17T09:15:00Z', lastResult: 'passed', automation: 'automated' },
  { id: 'TC-1025', title: 'Password reset flow', module: 'Authentication', priority: 'high', type: 'regression', status: 'active', steps: 8, lastRun: '2026-06-17T09:20:00Z', lastResult: 'failed', automation: 'automated' },
  { id: 'TC-2048', title: 'Policy creation end-to-end', module: 'Policy Management', priority: 'critical', type: 'e2e', status: 'active', steps: 12, lastRun: '2026-06-17T09:25:00Z', lastResult: 'not-run', automation: 'semi-automated' },
  { id: 'TC-2049', title: 'Claim submission validation', module: 'Claims', priority: 'high', type: 'functional', status: 'active', steps: 7, lastRun: '2026-06-17T09:30:00Z', lastResult: 'passed', automation: 'automated' },
  { id: 'TC-3072', title: 'Premium calculation engine', module: 'Rating Engine', priority: 'critical', type: 'integration', status: 'active', steps: 15, lastRun: '2026-06-17T09:35:00Z', lastResult: 'failed', automation: 'automated' },
  { id: 'TC-3073', title: 'Document upload verification', module: 'Document Management', priority: 'medium', type: 'functional', status: 'active', steps: 6, lastRun: '2026-06-17T09:40:00Z', lastResult: 'passed', automation: 'manual' },
  { id: 'TC-4096', title: 'Customer search and filter', module: 'Customer Portal', priority: 'medium', type: 'smoke', status: 'active', steps: 4, lastRun: '2026-06-17T09:45:00Z', lastResult: 'passed', automation: 'automated' },
  { id: 'TC-4097', title: 'Batch payment processing', module: 'Payments', priority: 'high', type: 'integration', status: 'active', steps: 10, lastRun: '2026-06-17T09:50:00Z', lastResult: 'failed', automation: 'automated' },
  { id: 'TC-5120', title: 'Report generation stress test', module: 'Reporting', priority: 'low', type: 'regression', status: 'draft', steps: 3, lastRun: '-', lastResult: 'not-run', automation: 'automated' },
  { id: 'TC-5121', title: 'API rate limiting validation', module: 'API Gateway', priority: 'medium', type: 'functional', status: 'active', steps: 6, lastRun: '2026-06-17T10:00:00Z', lastResult: 'passed', automation: 'automated' },
];

export const chatHistory: ChatMessage[] = [
  { id: '1', role: 'assistant', content: 'Hello! I\'m your Smart QE AI Assistant. I can help you analyze test results, identify risk areas, generate test cases, and provide quality insights. What would you like to explore?', timestamp: '2026-06-17T09:00:00Z', suggestions: ['Show me the current risk areas', 'Analyze recent test failures', 'Generate test cases for a module', 'What should I focus on this sprint?'] },
];

export const aiInsights: AIInsight[] = [
  { id: '1', type: 'risk', title: 'Authentication module at risk', description: 'Login and session management failures have increased by 40% in the last 3 builds. Root cause analysis suggests a recent OAuth library update introduced a regression.', confidence: 92, impact: 'high', timestamp: '2026-06-17T08:00:00Z' },
  { id: '2', type: 'anomaly', title: 'Unusual test duration spike', description: 'Batch payment processing tests are taking 3x longer than baseline. Possible database connection pool exhaustion under load.', confidence: 87, impact: 'medium', timestamp: '2026-06-17T07:30:00Z' },
  { id: '3', type: 'optimization', title: 'Smoke test suite can be reduced', description: 'Analysis shows 15 smoke tests have 100% pass rate over 30+ runs with no code changes in covered areas. Consider moving to weekly execution to reduce CI time by 8 minutes.', confidence: 78, impact: 'low', timestamp: '2026-06-17T07:00:00Z' },
  { id: '4', type: 'prediction', title: 'Rating Engine likely to fail next build', description: 'Code churn in premium calculation module is 3x above average with 2 open critical defects. Historical data suggests 85% probability of regression in the next deployment.', confidence: 85, impact: 'high', timestamp: '2026-06-17T06:00:00Z' },
];

export const sprintMetrics: SprintMetric[] = [
  { sprint: 'Sprint 19', passRate: 78, defectCount: 52, executionCount: 1820, automationRate: 55 },
  { sprint: 'Sprint 20', passRate: 81, defectCount: 48, executionCount: 1950, automationRate: 58 },
  { sprint: 'Sprint 21', passRate: 79, defectCount: 55, executionCount: 2100, automationRate: 61 },
  { sprint: 'Sprint 22', passRate: 83, defectCount: 41, executionCount: 2300, automationRate: 65 },
  { sprint: 'Sprint 23', passRate: 85, defectCount: 38, executionCount: 2500, automationRate: 68 },
  { sprint: 'Sprint 24', passRate: 87.3, defectCount: 34, executionCount: 2847, automationRate: 72 },
];

export const trendData: TrendData[] = [
  { date: 'Jun 11', passed: 245, failed: 28, skipped: 12 },
  { date: 'Jun 12', passed: 258, failed: 25, skipped: 10 },
  { date: 'Jun 13', passed: 262, failed: 30, skipped: 8 },
  { date: 'Jun 14', passed: 270, failed: 22, skipped: 14 },
  { date: 'Jun 15', passed: 278, failed: 18, skipped: 11 },
  { date: 'Jun 16', passed: 285, failed: 20, skipped: 9 },
  { date: 'Jun 17', passed: 291, failed: 15, skipped: 7 },
];

export const defectDistribution = [
  { module: 'Authentication', critical: 2, high: 1, medium: 1, low: 0 },
  { module: 'Policy Mgmt', critical: 0, high: 1, medium: 2, low: 1 },
  { module: 'Claims', critical: 0, high: 0, medium: 1, low: 2 },
  { module: 'Rating Engine', critical: 1, high: 1, medium: 0, low: 0 },
  { module: 'Documents', critical: 0, high: 1, medium: 0, low: 1 },
  { module: 'Payments', critical: 0, high: 1, medium: 1, low: 0 },
];
