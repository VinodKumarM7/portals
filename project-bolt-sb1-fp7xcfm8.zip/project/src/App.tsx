import { useMemo } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider, CssBaseline } from '@mui/material';
import { lightTheme, darkTheme } from './theme/theme';
import { useThemeMode } from './hooks/useApi';
import AppLayout from './components/layout/AppLayout';
import DashboardPage from './components/dashboard/DashboardPage';
import ChatPage from './components/chat/ChatPage';
import ExecutionPage from './components/execution/ExecutionPage';
import DefectsPage from './components/defects/DefectsPage';
import TestCasesPage from './components/testcases/TestCasesPage';
import ReportsPage from './components/reports/ReportsPage';
import SettingsPage from './components/settings/SettingsPage';

export default function App() {
  const { darkMode, toggle: toggleDark } = useThemeMode();
  const theme = useMemo(() => darkMode ? darkTheme : lightTheme, [darkMode]);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <Routes>
          <Route element={<AppLayout darkMode={darkMode} onToggleDark={toggleDark} />}>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/execution" element={<ExecutionPage />} />
            <Route path="/defects" element={<DefectsPage />} />
            <Route path="/testcases" element={<TestCasesPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="/settings" element={<SettingsPage darkMode={darkMode} onToggleDark={toggleDark} />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
