import { Box, Card, CardContent, Typography, Grid, alpha } from '@mui/material';
import { BarChart3, TrendingUp, Zap, Target } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RTooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { useApi } from '../../hooks/useApi';
import { api } from '../../services/api';

const PIE_COLORS = ['#C5281C', '#E05548', '#FFC107', '#28A745', '#1A73E8', '#6C757D'];

function StatCard({ title, value, subtitle, icon: Icon, color }: { title: string; value: string; subtitle: string; icon: typeof BarChart3; color: string }) {
  return (
    <Card sx={{
      background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
      backdropFilter: 'blur(20px)',
    }}>
      <CardContent sx={{ p: 2.5, '&:last-child': { pb: 2.5 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
          <Box sx={{ p: 1, borderRadius: 2, background: alpha(color, 0.1), color }}>
            <Icon size={18} />
          </Box>
          <Typography variant="body2" sx={{ fontWeight: 500, color: 'text.secondary' }}>{title}</Typography>
        </Box>
        <Typography variant="h5" sx={{ fontWeight: 700, mb: 0.25 }}>{value}</Typography>
        <Typography variant="caption" sx={{ color: 'text.secondary' }}>{subtitle}</Typography>
      </CardContent>
    </Card>
  );
}

export default function ReportsPage() {
  const { data: trends } = useApi(() => api.getTrendData());
  const { data: sprints } = useApi(() => api.getSprintMetrics());
  const { data: defectDist } = useApi(() => api.getDefectDistribution());

  const pieData = defectDist?.map(d => ({ name: d.module, value: d.critical + d.high + d.medium + d.low })) || [];

  const radarData = [
    { subject: 'Pass Rate', A: 87, fullMark: 100 },
    { subject: 'Automation', A: 72, fullMark: 100 },
    { subject: 'Coverage', A: 78, fullMark: 100 },
    { subject: 'Defect Density', A: 65, fullMark: 100 },
    { subject: 'Flake Rate', A: 92, fullMark: 100 },
    { subject: 'Speed', A: 80, fullMark: 100 },
  ];

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <BarChart3 size={28} color="#C5281C" />
          Reports & Analytics
        </Typography>
        <Typography variant="body2" sx={{ color: 'text.secondary' }}>Comprehensive quality engineering metrics and trend analysis</Typography>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard title="Quality Score" value="87.3" subtitle="out of 100" icon={Target} color="#28A745" />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard title="Sprint Velocity" value="+12.5%" subtitle="vs previous sprint" icon={TrendingUp} color="#1A73E8" />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard title="AI Insights" value="4" subtitle="active recommendations" icon={Zap} color="#FFC107" />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <StatCard title="Risk Index" value="Medium" subtitle="2 high risk modules" icon={BarChart3} color="#C5281C" />
        </Grid>
      </Grid>

      <Grid container spacing={2.5}>
        <Grid size={{ xs: 12, lg: 6 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
          }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2.5, fontWeight: 600 }}>Execution Trend (Last 7 Days)</Typography>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={trends || []} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="rPassedGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#28A745" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#28A745" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="rFailedGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#C5281C" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#C5281C" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <RTooltip contentStyle={{ borderRadius: 8, border: '1px solid rgba(0,0,0,0.08)' }} />
                  <Area type="monotone" dataKey="passed" stroke="#28A745" fill="url(#rPassedGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="failed" stroke="#C5281C" fill="url(#rFailedGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="skipped" stroke="#6C757D" fill="rgba(108,117,125,0.05)" strokeWidth={1} strokeDasharray="5 5" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 6 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
          }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2.5, fontWeight: 600 }}>Defect Distribution by Module</Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={defectDist || []} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                  <XAxis dataKey="module" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <RTooltip contentStyle={{ borderRadius: 8, border: '1px solid rgba(0,0,0,0.08)' }} />
                  <Bar dataKey="critical" stackId="a" fill="#C5281C" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="high" stackId="a" fill="#E05548" />
                  <Bar dataKey="medium" stackId="a" fill="#FFC107" />
                  <Bar dataKey="low" stackId="a" fill="#28A745" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6, lg: 4 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
          }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2.5, fontWeight: 600 }}>Quality Radar</Typography>
              <ResponsiveContainer width="100%" height={280}>
                <RadarChart data={radarData}>
                  <PolarGrid stroke="rgba(0,0,0,0.1)" />
                  <PolarAngleAxis dataKey="subject" tick={{ fontSize: 11 }} />
                  <PolarRadiusAxis tick={{ fontSize: 10 }} domain={[0, 100]} />
                  <Radar name="Current" dataKey="A" stroke="#C5281C" fill="#C5281C" fillOpacity={0.15} strokeWidth={2} />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 6, lg: 4 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
          }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2.5, fontWeight: 600 }}>Defects by Module</Typography>
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" outerRadius={100} innerRadius={55} paddingAngle={3} dataKey="value" label={({ name, percent = 0 }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={{ stroke: 'rgba(0,0,0,0.2)' }}>
                    {pieData.map((_, index) => <Cell key={index} fill={PIE_COLORS[index % PIE_COLORS.length]} />)}
                  </Pie>
                  <RTooltip contentStyle={{ borderRadius: 8 }} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, md: 12, lg: 4 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
          }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2.5, fontWeight: 600 }}>Sprint-over-Sprint Progress</Typography>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={sprints || []} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                  <XAxis dataKey="sprint" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <RTooltip contentStyle={{ borderRadius: 8 }} />
                  <Bar dataKey="passRate" fill="#28A745" radius={[4, 4, 0, 0]} name="Pass Rate %" />
                  <Bar dataKey="automationRate" fill="#1A73E8" radius={[4, 4, 0, 0]} name="Automation %" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
