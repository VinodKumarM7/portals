import { Box, Grid, Card, CardContent, Typography, Chip, LinearProgress, Skeleton, alpha } from '@mui/material';
import { TrendingUp, TrendingDown, AlertTriangle, Zap, BarChart3, Activity } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RTooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { useApi } from '../../hooks/useApi';
import { api } from '../../services/api';
import type { KPIMetric, AIInsight } from '../../types';

function KPIIcon({ icon }: { icon: string }) {
  const props = { size: 22 };
  switch (icon) {
    case 'TestTube': return <Activity {...props} />;
    case 'CheckCircle': return <TrendingUp {...props} />;
    case 'BugReport': return <AlertTriangle {...props} />;
    case 'SmartToy': return <Zap {...props} />;
    default: return <BarChart3 {...props} />;
  }
}

function KPICard({ metric }: { metric: KPIMetric }) {
  const isPositive = metric.change >= 0;
  return (
    <Card sx={{
      background: (theme) => theme.palette.mode === 'dark'
        ? 'rgba(30,30,30,0.7)'
        : 'rgba(255,255,255,0.8)',
      backdropFilter: 'blur(20px)',
      border: (theme) => `1px solid ${theme.palette.divider}`,
      position: 'relative',
      overflow: 'hidden',
    }}>
      <Box sx={{
        position: 'absolute', top: 0, right: 0, width: 100, height: 100,
        background: `radial-gradient(circle at top right, ${alpha(metric.color, 0.1)} 0%, transparent 70%)`,
      }} />
      <CardContent sx={{ p: 2.5, '&:last-child': { pb: 2.5 } }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', mb: 2 }}>
          <Box sx={{
            p: 1, borderRadius: 2,
            background: alpha(metric.color, 0.1),
            color: metric.color,
            display: 'flex', alignItems: 'center',
          }}>
            <KPIIcon icon={metric.icon} />
          </Box>
          <Chip
            size="small"
            icon={isPositive ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
            label={`${isPositive ? '+' : ''}${metric.change}%`}
            sx={{
              fontWeight: 600, fontSize: '0.75rem',
              bgcolor: alpha(isPositive ? '#28A745' : '#C5281C', 0.1),
              color: isPositive ? '#28A745' : '#C5281C',
            }}
          />
        </Box>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5, letterSpacing: '-0.02em' }}>
          {metric.value}
        </Typography>
        <Typography variant="body2" sx={{ color: 'text.secondary', mb: 0.5 }}>
          {metric.title}
        </Typography>
        <Typography variant="caption" sx={{ color: 'text.secondary', opacity: 0.7 }}>
          {metric.changeLabel}
        </Typography>
      </CardContent>
    </Card>
  );
}

function InsightCard({ insight }: { insight: AIInsight }) {
  const typeConfig = {
    risk: { color: '#C5281C', bg: 'rgba(197,40,28,0.08)', icon: AlertTriangle },
    anomaly: { color: '#FFC107', bg: 'rgba(255,193,7,0.08)', icon: Activity },
    optimization: { color: '#28A745', bg: 'rgba(40,167,69,0.08)', icon: TrendingUp },
    prediction: { color: '#1A73E8', bg: 'rgba(26,115,232,0.08)', icon: Zap },
  }[insight.type];

  const Icon = typeConfig.icon;

  return (
    <Card sx={{
      background: typeConfig.bg,
      border: `1px solid ${alpha(typeConfig.color, 0.15)}`,
    }}>
      <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
          <Icon size={16} color={typeConfig.color} />
          <Typography variant="subtitle2" sx={{ fontWeight: 600, flex: 1 }}>{insight.title}</Typography>
          <Chip label={insight.impact} size="small" sx={{
            fontWeight: 600, fontSize: '0.65rem', height: 20,
            bgcolor: alpha(typeConfig.color, 0.12), color: typeConfig.color,
          }} />
        </Box>
        <Typography variant="body2" sx={{ color: 'text.secondary', mb: 1, lineHeight: 1.5, fontSize: '0.8rem' }}>
          {insight.description}
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <LinearProgress
            variant="determinate"
            value={insight.confidence}
            sx={{
              flex: 1, height: 4, borderRadius: 2,
              bgcolor: alpha(typeConfig.color, 0.1),
              '& .MuiLinearProgress-bar': { borderRadius: 2, background: typeConfig.color },
            }}
          />
          <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600 }}>
            {insight.confidence}%
          </Typography>
        </Box>
      </CardContent>
    </Card>
  );
}

export default function DashboardPage() {
  const { data: kpis, loading: kpiLoading } = useApi(() => api.getKPIs());
  const { data: insights } = useApi(() => api.getAIInsights());
  const { data: trends } = useApi(() => api.getTrendData());
  const { data: sprintMetrics } = useApi(() => api.getSprintMetrics());

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>Quality Dashboard</Typography>
        <Typography variant="body2" sx={{ color: 'text.secondary' }}>
          Real-time quality engineering insights powered by AI
        </Typography>
      </Box>

      <Grid container spacing={2.5} sx={{ mb: 3 }}>
        {kpiLoading ? (
          [1, 2, 3, 4].map(i => (
            <Grid size={{ xs: 12, sm: 6, lg: 3 }} key={i}>
              <Card><CardContent><Skeleton height={120} /></CardContent></Card>
            </Grid>
          ))
        ) : (
          kpis?.map((kpi) => (
            <Grid size={{ xs: 12, sm: 6, lg: 3 }} key={kpi.id}>
              <KPICard metric={kpi} />
            </Grid>
          ))
        )}
      </Grid>

      <Grid container spacing={2.5}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
          }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2.5, fontWeight: 600 }}>Test Execution Trends</Typography>
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={trends || []} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                  <defs>
                    <linearGradient id="passedGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#28A745" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#28A745" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="failedGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#C5281C" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#C5281C" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                  <XAxis dataKey="date" tick={{ fontSize: 12 }} stroke="rgba(0,0,0,0.2)" />
                  <YAxis tick={{ fontSize: 12 }} stroke="rgba(0,0,0,0.2)" />
                  <RTooltip contentStyle={{ borderRadius: 8, border: '1px solid rgba(0,0,0,0.08)', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                  <Area type="monotone" dataKey="passed" stroke="#28A745" fill="url(#passedGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="failed" stroke="#C5281C" fill="url(#failedGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
            mb: 2.5,
          }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>Sprint Progress</Typography>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={sprintMetrics || []} margin={{ top: 5, right: 10, left: -10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                  <XAxis dataKey="sprint" tick={{ fontSize: 10 }} stroke="rgba(0,0,0,0.2)" />
                  <YAxis tick={{ fontSize: 12 }} stroke="rgba(0,0,0,0.2)" />
                  <RTooltip contentStyle={{ borderRadius: 8, border: '1px solid rgba(0,0,0,0.08)' }} />
                  <Bar dataKey="passRate" fill="#28A745" radius={[4, 4, 0, 0]} name="Pass Rate %" />
                  <Bar dataKey="automationRate" fill="#1A73E8" radius={[4, 4, 0, 0]} name="Automation %" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Box sx={{ mt: 2.5 }}>
        <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>AI Insights</Typography>
        <Grid container spacing={2}>
          {insights?.map((insight) => (
            <Grid size={{ xs: 12, md: 6 }} key={insight.id}>
              <InsightCard insight={insight} />
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  );
}
