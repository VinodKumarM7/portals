import { useState, useRef, useEffect } from 'react';
import { Box, Card, Typography, IconButton, TextField, Fab, Chip, Avatar, alpha, InputAdornment, Divider } from '@mui/material';
import { Send, Sparkles, Bot, User, Trash2 } from 'lucide-react';
import { api } from '../../services/api';
import type { ChatMessage } from '../../types';

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const initialized = useRef(false);

  useEffect(() => {
    if (!initialized.current) {
      initialized.current = true;
      api.sendChatMessage('__init__', []).then(msg => setMessages([msg]));
    }
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (text?: string) => {
    const message = text || input.trim();
    if (!message) return;

    const userMsg: ChatMessage = {
      id: String(Date.now()),
      role: 'user',
      content: message,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await api.sendChatMessage(message, messages);
      setMessages(prev => [...prev, response]);
    } catch {
      setMessages(prev => [...prev, {
        id: String(Date.now()),
        role: 'assistant',
        content: 'I apologize, I encountered an error processing your request. Please try again.',
        timestamp: new Date().toISOString(),
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleClear = () => {
    setMessages([]);
    initialized.current = false;
    api.sendChatMessage('__init__', []).then(msg => setMessages([msg]));
  };

  const renderContent = (content: string) => {
    return content.split('\n').map((line, i) => {
      let processed = line
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/^\d+\.\s/, (m) => `<span style="color:#C5281C;font-weight:600">${m}</span>`);
      if (line.startsWith('**')) processed = processed.replace(/^<strong>/, '<strong style="color:#C5281C">');
      return <div key={i} style={{ marginBottom: line ? '0.5rem' : '1rem' }} dangerouslySetInnerHTML={{ __html: processed || '&nbsp;' }} />;
    });
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 100px)' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <Sparkles size={28} color="#C5281C" />
            QE AI Assistant
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary' }}>
            Ask about test quality, risk analysis, or generate test cases
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <IconButton onClick={handleClear} sx={{ color: 'text.secondary' }}>
            <Trash2 size={18} />
          </IconButton>
        </Box>
      </Box>

      <Card sx={{
        flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden',
        background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.5)' : 'rgba(255,255,255,0.7)',
        backdropFilter: 'blur(20px)',
      }}>
        <Box ref={scrollRef} sx={{ flex: 1, overflow: 'auto', p: 3 }}>
          {messages.map((msg) => (
            <Box key={msg.id} sx={{
              display: 'flex', gap: 2, mb: 3,
              flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
            }}>
              <Avatar sx={{
                width: 36, height: 36, mt: 0.5,
                background: msg.role === 'user'
                  ? 'linear-gradient(135deg, #2E2E2E 0%, #4A4A4A 100%)'
                  : 'linear-gradient(135deg, #C5281C 0%, #E05548 100%)',
              }}>
                {msg.role === 'user' ? <User size={18} color="white" /> : <Bot size={18} color="white" />}
              </Avatar>
              <Box sx={{
                maxWidth: '70%',
                p: 2, borderRadius: 3,
                background: (theme) => msg.role === 'user'
                  ? alpha('#C5281C', 0.08)
                  : theme.palette.mode === 'dark'
                    ? 'rgba(255,255,255,0.06)'
                    : 'rgba(0,0,0,0.03)',
                border: (theme) => `1px solid ${theme.palette.divider}`,
                typography: 'body2', lineHeight: 1.7, fontSize: '0.9rem',
              }}>
                {renderContent(msg.content)}
                {msg.suggestions && (
                  <Box sx={{ mt: 2, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {msg.suggestions.map((s, i) => (
                      <Chip
                        key={i}
                        label={s}
                        size="small"
                        clickable
                        onClick={() => handleSend(s)}
                        sx={{
                          fontSize: '0.75rem',
                          borderColor: alpha('#C5281C', 0.3),
                          '&:hover': { bgcolor: alpha('#C5281C', 0.1), borderColor: '#C5281C' },
                        }}
                        variant="outlined"
                      />
                    ))}
                  </Box>
                )}
              </Box>
            </Box>
          ))}
          {isTyping && (
            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              <Avatar sx={{ width: 36, height: 36, background: 'linear-gradient(135deg, #C5281C 0%, #E05548 100%)' }}>
                <Bot size={18} color="white" />
              </Avatar>
              <Box sx={{
                p: 2, borderRadius: 3,
                background: (theme) => theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.03)',
                display: 'flex', gap: 0.5, alignItems: 'center',
              }}>
                {[0, 1, 2].map(i => (
                  <Box key={i} sx={{
                    width: 8, height: 8, borderRadius: '50%', bgcolor: '#C5281C',
                    animation: 'pulse 1.4s ease-in-out infinite',
                    animationDelay: `${i * 0.2}s`,
                    '@keyframes pulse': {
                      '0%, 80%, 100%': { opacity: 0.3, transform: 'scale(0.8)' },
                      '40%': { opacity: 1, transform: 'scale(1)' },
                    },
                  }} />
                ))}
              </Box>
            </Box>
          )}
        </Box>

        <Divider />
        <Box sx={{ p: 2, display: 'flex', gap: 1.5, alignItems: 'flex-end' }}>
          <TextField
            fullWidth
            multiline
            maxRows={4}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder="Ask about test quality, risk areas, or request analysis..."
            sx={{
              '& .MuiOutlinedInput-root': {
                borderRadius: 3, fontSize: '0.9rem',
                background: (theme) => theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.02)',
              },
            }}
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    <Fab
                      size="small"
                      color="primary"
                      onClick={() => handleSend()}
                      disabled={!input.trim() || isTyping}
                      sx={{
                        minWidth: 36, width: 36, height: 36,
                        background: 'linear-gradient(135deg, #C5281C 0%, #E05548 100%)',
                        boxShadow: '0 2px 8px rgba(197,40,28,0.3)',
                        '&:hover': { background: 'linear-gradient(135deg, #9E2016 0%, #C5281C 100%)' },
                      }}
                    >
                      <Send size={16} />
                    </Fab>
                  </InputAdornment>
                ),
              },
            }}
          />
        </Box>
      </Card>
    </Box>
  );
}
