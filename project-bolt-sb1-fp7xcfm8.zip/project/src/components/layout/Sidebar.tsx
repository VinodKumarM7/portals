import { useLocation, useNavigate } from 'react-router-dom';
import {
  Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText,
  IconButton, Box, Typography, Divider, Tooltip,
} from '@mui/material';
import {
  LayoutDashboard, MessageSquare, PlayCircle, Bug, FileText,
  BarChart3, Settings, ChevronLeft, ChevronRight, TestTube, Zap,
} from 'lucide-react';

const DRAWER_WIDTH = 260;
const DRAWER_COLLAPSED = 68;

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/chat', label: 'AI Assistant', icon: MessageSquare },
  { path: '/execution', label: 'Test Execution', icon: PlayCircle },
  { path: '/defects', label: 'Defect Tracker', icon: Bug },
  { path: '/testcases', label: 'Test Cases', icon: FileText },
  { path: '/reports', label: 'Reports & Analytics', icon: BarChart3 },
  { path: '/settings', label: 'Settings', icon: Settings },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export default function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: collapsed ? DRAWER_COLLAPSED : DRAWER_WIDTH,
        transition: 'width 0.3s cubic-bezier(0.4,0,0.2,1)',
        '& .MuiDrawer-paper': {
          width: collapsed ? DRAWER_COLLAPSED : DRAWER_WIDTH,
          transition: 'width 0.3s cubic-bezier(0.4,0,0.2,1)',
          overflowX: 'hidden',
          background: (theme) => theme.palette.mode === 'dark'
            ? 'linear-gradient(180deg, #1A1A1A 0%, #222222 100%)'
            : 'linear-gradient(180deg, #FFFFFF 0%, #F8F9FA 100%)',
        },
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'space-between', px: collapsed ? 0 : 2.5, py: 2, minHeight: 64 }}>
        {!collapsed && (
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <Box sx={{
              width: 36, height: 36, borderRadius: 2,
              background: 'linear-gradient(135deg, #C5281C 0%, #E05548 100%)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 2px 8px rgba(197,40,28,0.3)',
            }}>
              <TestTube size={20} color="white" />
            </Box>
            <Box>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: 'text.primary', lineHeight: 1.2 }}>Smart QE</Typography>
              <Typography variant="caption" sx={{ color: 'text.secondary', lineHeight: 1, fontSize: '0.65rem' }}>AI Assistant</Typography>
            </Box>
          </Box>
        )}
        <IconButton onClick={onToggle} size="small" sx={{ color: 'text.secondary' }}>
          {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </IconButton>
      </Box>

      <Divider />

      <List sx={{ px: 1, py: 1 }}>
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Tooltip key={item.path} title={collapsed ? item.label : ''} placement="right" arrow>
              <ListItem disablePadding sx={{ mb: 0.5 }}>
                <ListItemButton
                  onClick={() => navigate(item.path)}
                  sx={{
                    borderRadius: 2,
                    minHeight: 44,
                    px: collapsed ? 0 : 2,
                    justifyContent: collapsed ? 'center' : 'flex-start',
                    gap: collapsed ? 0 : 1.5,
                    background: isActive
                      ? 'linear-gradient(135deg, rgba(197,40,28,0.12) 0%, rgba(197,40,28,0.06) 100%)'
                      : 'transparent',
                    color: isActive ? '#C5281C' : 'text.secondary',
                    '&:hover': {
                      background: isActive
                        ? 'linear-gradient(135deg, rgba(197,40,28,0.16) 0%, rgba(197,40,28,0.08) 100%)'
                        : 'rgba(0,0,0,0.04)',
                    },
                    transition: 'all 0.2s ease',
                  }}
                >
                  <ListItemIcon sx={{
                    minWidth: collapsed ? 'unset' : 36,
                    color: isActive ? '#C5281C' : 'text.secondary',
                    justifyContent: 'center',
                  }}>
                    <Icon size={20} />
                  </ListItemIcon>
                  {!collapsed && (
                    <ListItemText
                      primary={item.label}
                      slotProps={{ primary: { sx: { fontWeight: isActive ? 600 : 400, fontSize: '0.875rem' } } }}
                    />
                  )}
                </ListItemButton>
              </ListItem>
            </Tooltip>
          );
        })}
      </List>

      <Box sx={{ flexGrow: 1 }} />

      {!collapsed && (
        <Box sx={{ px: 2.5, pb: 2 }}>
          <Box sx={{
            p: 2, borderRadius: 2.5,
            background: 'linear-gradient(135deg, rgba(197,40,28,0.08) 0%, rgba(197,40,28,0.03) 100%)',
            border: '1px solid rgba(197,40,28,0.12)',
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1 }}>
              <Zap size={16} color="#C5281C" />
              <Typography variant="caption" sx={{ fontWeight: 600, color: '#C5281C' }}>AI Powered</Typography>
            </Box>
            <Typography variant="caption" sx={{ color: 'text.secondary', lineHeight: 1.4 }}>
              Intelligent quality insights and test automation
            </Typography>
          </Box>
        </Box>
      )}
    </Drawer>
  );
}
