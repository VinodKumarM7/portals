import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Box } from '@mui/material';
import Sidebar from './Sidebar';
import TopBar from './TopBar';

interface AppLayoutProps {
  darkMode: boolean;
  onToggleDark: () => void;
}

export default function AppLayout({ darkMode, onToggleDark }: AppLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', background: 'background.default' }}>
      <TopBar
        darkMode={darkMode}
        onToggleDark={onToggleDark}
        onToggleSidebar={() => setSidebarCollapsed(prev => !prev)}
      />
      <Sidebar
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(prev => !prev)}
      />
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          pt: '72px',
          px: 3,
          pb: 3,
          minHeight: '100vh',
          overflow: 'auto',
        }}
      >
        <Outlet />
      </Box>
    </Box>
  );
}
