import { AppBar, Toolbar, IconButton, Box, Chip, Avatar, Badge, InputBase } from '@mui/material';
import { Bell, Search, Moon, Sun, Menu } from 'lucide-react';

interface TopBarProps {
  darkMode: boolean;
  onToggleDark: () => void;
  onToggleSidebar: () => void;
}

export default function TopBar({ darkMode, onToggleDark, onToggleSidebar }: TopBarProps) {
  return (
    <AppBar
      position="fixed"
      elevation={0}
      sx={{
        zIndex: (theme) => theme.zIndex.drawer + 1,
        background: (theme) => theme.palette.mode === 'dark'
          ? 'rgba(18,18,18,0.85)'
          : 'rgba(255,255,255,0.85)',
        backdropFilter: 'blur(20px)',
        borderBottom: (theme) => `1px solid ${theme.palette.divider}`,
        color: 'text.primary',
      }}
    >
      <Toolbar sx={{ gap: 2, minHeight: '56px !important' }}>
        <IconButton onClick={onToggleSidebar} edge="start" sx={{ color: 'text.secondary' }}>
          <Menu size={20} />
        </IconButton>

        <Box sx={{
          display: 'flex', alignItems: 'center', gap: 1,
          background: (theme) => theme.palette.mode === 'dark'
            ? 'rgba(255,255,255,0.06)'
            : 'rgba(0,0,0,0.04)',
          borderRadius: 2, px: 2, py: 0.5, flex: 1, maxWidth: 480,
        }}>
          <Search size={16} style={{ opacity: 0.5 }} />
          <InputBase
            placeholder="Search tests, defects, insights..."
            sx={{ flex: 1, fontSize: '0.875rem', '& input': { py: 0.5 } }}
          />
        </Box>

        <Box sx={{ flexGrow: 1 }} />

        <Chip
          label="Sprint 24"
          size="small"
          sx={{
            fontWeight: 600,
            background: 'linear-gradient(135deg, rgba(197,40,28,0.1) 0%, rgba(197,40,28,0.05) 100%)',
            color: '#C5281C',
            borderColor: 'rgba(197,40,28,0.2)',
          }}
          variant="outlined"
        />

        <Chip
          label="Build B-4.2.2"
          size="small"
          sx={{ fontWeight: 500 }}
          variant="outlined"
        />

        <IconButton onClick={onToggleDark} sx={{ color: 'text.secondary' }}>
          {darkMode ? <Sun size={20} /> : <Moon size={20} />}
        </IconButton>

        <IconButton sx={{ color: 'text.secondary' }}>
          <Badge badgeContent={3} color="error" variant="dot">
            <Bell size={20} />
          </Badge>
        </IconButton>

        <Avatar sx={{
          width: 34, height: 34, fontSize: '0.8rem', fontWeight: 600,
          background: 'linear-gradient(135deg, #C5281C 0%, #E05548 100%)',
        }}>
          SC
        </Avatar>
      </Toolbar>
    </AppBar>
  );
}
