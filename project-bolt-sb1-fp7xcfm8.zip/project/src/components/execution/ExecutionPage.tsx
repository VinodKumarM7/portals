import { useState } from 'react';
import { Box, Card, Typography, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, IconButton, TextField, InputAdornment, MenuItem, Select, FormControl, alpha, Tooltip } from '@mui/material';
import { Search, RefreshCw, CheckCircle2, XCircle, AlertTriangle, SkipForward, MoreVertical } from 'lucide-react';
import { useApi } from '../../hooks/useApi';
import { api } from '../../services/api';

const statusConfig = {
  passed: { color: '#28A745', bg: 'rgba(40,167,69,0.1)', icon: CheckCircle2, label: 'Passed' },
  failed: { color: '#C5281C', bg: 'rgba(197,40,28,0.1)', icon: XCircle, label: 'Failed' },
  running: { color: '#1A73E8', bg: 'rgba(26,115,232,0.1)', icon: RefreshCw, label: 'Running' },
  blocked: { color: '#FFC107', bg: 'rgba(255,193,7,0.1)', icon: AlertTriangle, label: 'Blocked' },
  skipped: { color: '#6C757D', bg: 'rgba(108,117,125,0.1)', icon: SkipForward, label: 'Skipped' },
};

export default function ExecutionPage() {
  const [statusFilter, setStatusFilter] = useState('all');
  const [suiteFilter, setSuiteFilter] = useState('all');
  const [search, setSearch] = useState('');

  const { data: executions, loading, refetch } = useApi(
    () => api.getTestExecutions({ status: statusFilter !== 'all' ? statusFilter : undefined, suite: suiteFilter !== 'all' ? suiteFilter : undefined }),
    [statusFilter, suiteFilter]
  );

  const filtered = executions?.filter(e =>
    e.testName.toLowerCase().includes(search.toLowerCase()) ||
    e.testCaseId.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const suites = [...new Set((executions || []).map(e => e.suite))];
  const counts = { passed: 0, failed: 0, running: 0, blocked: 0, skipped: 0 };
  executions?.forEach(e => { counts[e.status]++; });

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700 }}>Test Execution</Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary' }}>Monitor and track test run results</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          {Object.entries(statusConfig).map(([key, cfg]) => {
            const Icon = cfg.icon;
            const count = counts[key as keyof typeof counts];
            return (
              <Chip
                key={key}
                icon={<Icon size={14} color={cfg.color} />}
                label={`${count} ${cfg.label}`}
                size="small"
                variant={statusFilter === key ? 'filled' : 'outlined'}
                onClick={() => setStatusFilter(statusFilter === key ? 'all' : key)}
                sx={{
                  fontWeight: 600, fontSize: '0.75rem',
                  borderColor: alpha(cfg.color, 0.3),
                  bgcolor: statusFilter === key ? cfg.bg : 'transparent',
                  color: cfg.color,
                  '& .MuiChip-icon': { ml: '4px' },
                }}
              />
            );
          })}
        </Box>
      </Box>

      <Card sx={{
        background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
        backdropFilter: 'blur(20px)',
      }}>
        <Box sx={{ p: 2.5, display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
          <TextField
            size="small"
            placeholder="Search test executions..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 200 }}
            slotProps={{
              input: {
                startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment>,
              },
            }}
          />
          <FormControl size="small" sx={{ minWidth: 160 }}>
            <Select value={suiteFilter} onChange={(e) => setSuiteFilter(e.target.value)}>
              <MenuItem value="all">All Suites</MenuItem>
              {suites.map(s => <MenuItem key={s} value={s}>{s}</MenuItem>)}
            </Select>
          </FormControl>
          <IconButton onClick={() => refetch()} sx={{ color: 'text.secondary' }}>
            <RefreshCw size={18} />
          </IconButton>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Test Name</TableCell>
                <TableCell>Suite</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Duration</TableCell>
                <TableCell>Executed By</TableCell>
                <TableCell>Environment</TableCell>
                <TableCell>Build</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                [1, 2, 3].map(i => (
                  <TableRow key={i}>
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(j => (
                      <TableCell key={j}><Box sx={{ height: 20, bgcolor: 'action.hover', borderRadius: 1, animation: 'pulse 2s infinite' }} /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 6, color: 'text.secondary' }}>
                    No test executions found matching your criteria
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((exec) => {
                  const cfg = statusConfig[exec.status];
                  const Icon = cfg.icon;
                  return (
                    <TableRow key={exec.id} hover sx={{ '&:hover': { bgcolor: alpha(cfg.color, 0.03) } }}>
                      <TableCell><Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main', fontFamily: 'monospace', fontSize: '0.8rem' }}>{exec.testCaseId}</Typography></TableCell>
                      <TableCell><Typography variant="body2" sx={{ fontWeight: 500 }}>{exec.testName}</Typography></TableCell>
                      <TableCell><Chip label={exec.suite} size="small" variant="outlined" sx={{ fontSize: '0.75rem' }} /></TableCell>
                      <TableCell>
                        <Chip
                          icon={<Icon size={14} color={cfg.color} />}
                          label={cfg.label}
                          size="small"
                          sx={{ fontWeight: 600, bgcolor: cfg.bg, color: cfg.color, fontSize: '0.75rem', '& .MuiChip-icon': { ml: '2px' } }}
                        />
                      </TableCell>
                      <TableCell><Typography variant="body2" sx={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{exec.duration}</Typography></TableCell>
                      <TableCell><Typography variant="body2">{exec.executedBy}</Typography></TableCell>
                      <TableCell><Chip label={exec.environment} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} /></TableCell>
                      <TableCell><Typography variant="caption" sx={{ fontFamily: 'monospace' }}>{exec.buildNumber}</Typography></TableCell>
                      <TableCell align="right">
                        <Tooltip title="View details"><IconButton size="small"><MoreVertical size={16} /></IconButton></Tooltip>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>
    </Box>
  );
}
