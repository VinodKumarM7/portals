import { useState } from 'react';
import { Box, Card, Typography, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, IconButton, TextField, InputAdornment, MenuItem, Select, FormControl, alpha, Tooltip } from '@mui/material';
import { Search, RefreshCw, FileText, Bot, User, ArrowUpRight, CheckCircle2, XCircle, MinusCircle } from 'lucide-react';
import { useApi } from '../../hooks/useApi';
import { api } from '../../services/api';

const priorityConfig = {
  critical: { color: '#C5281C', bg: 'rgba(197,40,28,0.1)' },
  high: { color: '#E05548', bg: 'rgba(224,85,72,0.1)' },
  medium: { color: '#FFC107', bg: 'rgba(255,193,7,0.1)' },
  low: { color: '#28A745', bg: 'rgba(40,167,69,0.1)' },
};

const resultConfig = {
  passed: { color: '#28A745', bg: 'rgba(40,167,69,0.1)', icon: CheckCircle2, label: 'Passed' },
  failed: { color: '#C5281C', bg: 'rgba(197,40,28,0.1)', icon: XCircle, label: 'Failed' },
  'not-run': { color: '#6C757D', bg: 'rgba(108,117,125,0.1)', icon: MinusCircle, label: 'Not Run' },
};

const automationConfig = {
  automated: { color: '#1A73E8', bg: 'rgba(26,115,232,0.1)', icon: Bot, label: 'Automated' },
  manual: { color: '#FFC107', bg: 'rgba(255,193,7,0.1)', icon: User, label: 'Manual' },
  'semi-automated': { color: '#6C757D', bg: 'rgba(108,117,125,0.1)', icon: User, label: 'Semi-Auto' },
};

export default function TestCasesPage() {
  const [moduleFilter, setModuleFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [autoFilter, setAutoFilter] = useState('all');
  const [search, setSearch] = useState('');

  const { data: testCases, loading, refetch } = useApi(
    () => api.getTestCases({ module: moduleFilter !== 'all' ? moduleFilter : undefined, type: typeFilter !== 'all' ? typeFilter : undefined, automation: autoFilter !== 'all' ? autoFilter : undefined }),
    [moduleFilter, typeFilter, autoFilter]
  );

  const filtered = testCases?.filter(tc =>
    tc.title.toLowerCase().includes(search.toLowerCase()) || tc.id.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const modules = [...new Set((testCases || []).map(tc => tc.module))];
  const types = [...new Set((testCases || []).map(tc => tc.type))];

  const autoCounts = { automated: 0, manual: 0, 'semi-automated': 0 };
  testCases?.forEach(tc => { autoCounts[tc.automation]++; });

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <FileText size={28} color="#C5281C" />
            Test Cases
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary' }}>Manage and organize your test case repository</Typography>
        </Box>
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
          {Object.entries(automationConfig).map(([key, cfg]) => {
            const Icon = cfg.icon;
            const count = autoCounts[key as keyof typeof autoCounts];
            return (
              <Chip key={key} icon={<Icon size={14} color={cfg.color} />} label={`${count} ${cfg.label}`} size="small" variant="outlined" sx={{ fontWeight: 600, fontSize: '0.75rem', borderColor: alpha(cfg.color, 0.3), color: cfg.color, '& .MuiChip-icon': { ml: '4px' } }} />
            );
          })}
          <IconButton onClick={() => refetch()} sx={{ color: 'text.secondary', ml: 1 }}><RefreshCw size={18} /></IconButton>
        </Box>
      </Box>

      <Card sx={{
        background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
        backdropFilter: 'blur(20px)',
      }}>
        <Box sx={{ p: 2.5, display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
          <TextField
            size="small" placeholder="Search test cases..." value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 200 }}
            slotProps={{ input: { startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment> } }}
          />
          <FormControl size="small" sx={{ minWidth: 150 }}>
            <Select value={moduleFilter} onChange={(e) => setModuleFilter(e.target.value)}>
              <MenuItem value="all">All Modules</MenuItem>
              {modules.map(m => <MenuItem key={m} value={m}>{m}</MenuItem>)}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 140 }}>
            <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              <MenuItem value="all">All Types</MenuItem>
              {types.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
            </Select>
          </FormControl>
          <FormControl size="small" sx={{ minWidth: 140 }}>
            <Select value={autoFilter} onChange={(e) => setAutoFilter(e.target.value)}>
              <MenuItem value="all">All Automation</MenuItem>
              {Object.entries(automationConfig).map(([k, v]) => <MenuItem key={k} value={k}>{v.label}</MenuItem>)}
            </Select>
          </FormControl>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Title</TableCell>
                <TableCell>Module</TableCell>
                <TableCell>Priority</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Automation</TableCell>
                <TableCell>Last Result</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                [1, 2, 3].map(i => (
                  <TableRow key={i}>{Array(9).fill(0).map((_, j) => (
                    <TableCell key={j}><Box sx={{ height: 20, bgcolor: 'action.hover', borderRadius: 1 }} /></TableCell>
                  ))}</TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={9} align="center" sx={{ py: 6, color: 'text.secondary' }}>No test cases found</TableCell></TableRow>
              ) : (
                filtered.map((tc) => {
                  const pCfg = priorityConfig[tc.priority];
                  const rCfg = resultConfig[tc.lastResult];
                  const aCfg = automationConfig[tc.automation];
                  const RIcon = rCfg.icon;
                  const AIcon = aCfg.icon;
                  return (
                    <TableRow key={tc.id} hover>
                      <TableCell><Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main', fontFamily: 'monospace', fontSize: '0.8rem' }}>{tc.id}</Typography></TableCell>
                      <TableCell sx={{ maxWidth: 260 }}><Typography variant="body2" sx={{ fontWeight: 500 }}>{tc.title}</Typography></TableCell>
                      <TableCell><Chip label={tc.module} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} /></TableCell>
                      <TableCell><Chip label={tc.priority} size="small" sx={{ fontWeight: 600, bgcolor: pCfg.bg, color: pCfg.color, textTransform: 'capitalize', fontSize: '0.75rem' }} /></TableCell>
                      <TableCell><Typography variant="caption" sx={{ textTransform: 'capitalize' }}>{tc.type}</Typography></TableCell>
                      <TableCell><Chip icon={<AIcon size={14} color={aCfg.color} />} label={aCfg.label} size="small" sx={{ fontWeight: 600, bgcolor: aCfg.bg, color: aCfg.color, fontSize: '0.75rem', '& .MuiChip-icon': { ml: '2px' } }} /></TableCell>
                      <TableCell>
                        {tc.lastResult !== 'not-run' ? (
                          <Chip icon={<RIcon size={14} color={rCfg.color} />} label={rCfg.label} size="small" sx={{ fontWeight: 600, bgcolor: rCfg.bg, color: rCfg.color, fontSize: '0.75rem', '& .MuiChip-icon': { ml: '2px' } }} />
                        ) : (
                          <Typography variant="caption" sx={{ color: 'text.secondary' }}>-</Typography>
                        )}
                      </TableCell>
                      <TableCell>
                        <Chip label={tc.status} size="small" variant="outlined" sx={{ textTransform: 'capitalize', fontSize: '0.75rem', fontWeight: 500 }} />
                      </TableCell>
                      <TableCell align="right"><Tooltip title="View"><IconButton size="small"><ArrowUpRight size={16} /></IconButton></Tooltip></TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>
    </Box>
  );
}
