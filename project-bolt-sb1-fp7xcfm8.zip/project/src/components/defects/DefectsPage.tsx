import { useState } from 'react';
import { Box, Card, Typography, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, IconButton, TextField, InputAdornment, MenuItem, Select, FormControl, alpha, Tooltip, Grid } from '@mui/material';
import { Search, Bug, RefreshCw, AlertOctagon, AlertTriangle, Info, CheckCircle2, Clock, ArrowUpRight } from 'lucide-react';
import { useApi } from '../../hooks/useApi';
import { api } from '../../services/api';

const severityConfig = {
  critical: { color: '#C5281C', bg: 'rgba(197,40,28,0.1)', icon: AlertOctagon },
  high: { color: '#E05548', bg: 'rgba(224,85,72,0.1)', icon: AlertTriangle },
  medium: { color: '#FFC107', bg: 'rgba(255,193,7,0.1)', icon: Info },
  low: { color: '#28A745', bg: 'rgba(40,167,69,0.1)', icon: CheckCircle2 },
};

const statusConfig = {
  open: { color: '#C5281C', bg: 'rgba(197,40,28,0.1)', icon: AlertOctagon, label: 'Open' },
  'in-progress': { color: '#1A73E8', bg: 'rgba(26,115,232,0.1)', icon: Clock, label: 'In Progress' },
  resolved: { color: '#28A745', bg: 'rgba(40,167,69,0.1)', icon: CheckCircle2, label: 'Resolved' },
  closed: { color: '#6C757D', bg: 'rgba(108,117,125,0.1)', icon: CheckCircle2, label: 'Closed' },
  reopened: { color: '#FFC107', bg: 'rgba(255,193,7,0.1)', icon: AlertTriangle, label: 'Reopened' },
};

export default function DefectsPage() {
  const [severityFilter, setSeverityFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');

  const { data: defects, loading, refetch } = useApi(
    () => api.getDefects({ severity: severityFilter !== 'all' ? severityFilter : undefined, status: statusFilter !== 'all' ? statusFilter : undefined }),
    [severityFilter, statusFilter]
  );

  const filtered = defects?.filter(d =>
    d.title.toLowerCase().includes(search.toLowerCase()) ||
    d.id.toLowerCase().includes(search.toLowerCase()) ||
    d.module.toLowerCase().includes(search.toLowerCase())
  ) || [];

  const severityCounts = { critical: 0, high: 0, medium: 0, low: 0 };
  defects?.forEach(d => { severityCounts[d.severity]++; });

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
        <Box>
          <Typography variant="h4" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 1.5 }}>
            <Bug size={28} color="#C5281C" />
            Defect Tracker
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary' }}>Track and manage quality defects across sprints</Typography>
        </Box>
        <IconButton onClick={() => refetch()} sx={{ color: 'text.secondary' }}><RefreshCw size={18} /></IconButton>
      </Box>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        {Object.entries(severityConfig).map(([key, cfg]) => {
          const Icon = cfg.icon;
          const count = severityCounts[key as keyof typeof severityCounts];
          return (
            <Grid size={{ xs: 6, sm: 3 }} key={key}>
              <Card sx={{
                background: cfg.bg, border: `1px solid ${alpha(cfg.color, 0.15)}`,
                cursor: 'pointer',
                outline: severityFilter === key ? `2px solid ${cfg.color}` : 'none',
              }} onClick={() => setSeverityFilter(severityFilter === key ? 'all' : key)}>
                <Box sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 1.5 }}>
                  <Icon size={20} color={cfg.color} />
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="h5" sx={{ fontWeight: 700, color: cfg.color }}>{count}</Typography>
                    <Typography variant="caption" sx={{ color: cfg.color, textTransform: 'capitalize', fontWeight: 600 }}>{key}</Typography>
                  </Box>
                </Box>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      <Card sx={{
        background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
        backdropFilter: 'blur(20px)',
      }}>
        <Box sx={{ p: 2.5, display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
          <TextField
            size="small" placeholder="Search defects..." value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 200 }}
            slotProps={{ input: { startAdornment: <InputAdornment position="start"><Search size={16} /></InputAdornment> } }}
          />
          <FormControl size="small" sx={{ minWidth: 140 }}>
            <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              <MenuItem value="all">All Statuses</MenuItem>
              {Object.entries(statusConfig).map(([k, v]) => <MenuItem key={k} value={k}>{v.label}</MenuItem>)}
            </Select>
          </FormControl>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>ID</TableCell>
                <TableCell>Title</TableCell>
                <TableCell>Severity</TableCell>
                <TableCell>Priority</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Assignee</TableCell>
                <TableCell>Module</TableCell>
                <TableCell>Sprint</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                [1, 2, 3].map(i => (
                  <TableRow key={i}>
                    {Array(9).fill(0).map((_, j) => (
                      <TableCell key={j}><Box sx={{ height: 20, bgcolor: 'action.hover', borderRadius: 1 }} /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} align="center" sx={{ py: 6, color: 'text.secondary' }}>No defects found</TableCell>
                </TableRow>
              ) : (
                filtered.map((defect) => {
                  const sCfg = severityConfig[defect.severity];
                  const stCfg = statusConfig[defect.status];
                  const SIcon = sCfg.icon;
                  const StIcon = stCfg.icon;
                  return (
                    <TableRow key={defect.id} hover>
                      <TableCell><Typography variant="body2" sx={{ fontWeight: 600, color: 'primary.main', fontFamily: 'monospace', fontSize: '0.8rem' }}>{defect.id}</Typography></TableCell>
                      <TableCell sx={{ maxWidth: 280 }}><Typography variant="body2" sx={{ fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{defect.title}</Typography></TableCell>
                      <TableCell>
                        <Chip icon={<SIcon size={14} color={sCfg.color} />} label={defect.severity} size="small" sx={{ fontWeight: 600, bgcolor: sCfg.bg, color: sCfg.color, textTransform: 'capitalize', fontSize: '0.75rem', '& .MuiChip-icon': { ml: '2px' } }} />
                      </TableCell>
                      <TableCell><Chip label={defect.priority} size="small" variant="outlined" sx={{ fontWeight: 600, fontSize: '0.75rem' }} /></TableCell>
                      <TableCell>
                        <Chip icon={<StIcon size={14} color={stCfg.color} />} label={stCfg.label} size="small" sx={{ fontWeight: 600, bgcolor: stCfg.bg, color: stCfg.color, fontSize: '0.75rem', '& .MuiChip-icon': { ml: '2px' } }} />
                      </TableCell>
                      <TableCell><Typography variant="body2">{defect.assignee}</Typography></TableCell>
                      <TableCell><Chip label={defect.module} size="small" variant="outlined" sx={{ fontSize: '0.7rem' }} /></TableCell>
                      <TableCell><Typography variant="caption">{defect.sprint}</Typography></TableCell>
                      <TableCell align="right"><Tooltip title="View"><IconButton size="small"><ArrowUpRight size={16} /></IconButton></Tooltip></TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>
      </Card>
    </Box>
  );
}
