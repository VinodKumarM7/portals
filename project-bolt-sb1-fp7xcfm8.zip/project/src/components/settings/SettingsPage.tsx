import { useState } from 'react';
import { Box, Card, CardContent, Typography, Switch, FormGroup, Select, MenuItem, FormControl, InputLabel, Slider, Divider, Grid, Chip, alpha, Avatar } from '@mui/material';
import { Settings, Moon, Sun, Bell, Globe, RefreshCw, Palette } from 'lucide-react';

interface SettingsPageProps {
  darkMode: boolean;
  onToggleDark: () => void;
}

export default function SettingsPage({ darkMode, onToggleDark }: SettingsPageProps) {
  const [notifications, setNotifications] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(30);
  const [language, setLanguage] = useState('en');
  const [defaultView, setDefaultView] = useState('dashboard');

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" sx={{ fontWeight: 700, display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Settings size={28} color="#C5281C" />
          Settings
        </Typography>
        <Typography variant="body2" sx={{ color: 'text.secondary' }}>Configure your QE Assistant preferences</Typography>
      </Box>

      <Grid container spacing={2.5}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Grid container spacing={2.5}>
            <Grid size={{ xs: 12 }}>
              <Card sx={{
                background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
                backdropFilter: 'blur(20px)',
              }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2.5 }}>
                    <Palette size={20} color="#C5281C" />
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>Appearance</Typography>
                  </Box>
                  <FormGroup>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 1 }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        {darkMode ? <Moon size={20} /> : <Sun size={20} />}
                        <Box>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>Dark Mode</Typography>
                          <Typography variant="caption" sx={{ color: 'text.secondary' }}>Switch between light and dark themes</Typography>
                        </Box>
                      </Box>
                      <Switch checked={darkMode} onChange={onToggleDark} color="primary" />
                    </Box>
                  </FormGroup>
                </CardContent>
              </Card>
            </Grid>

            <Grid size={{ xs: 12 }}>
              <Card sx={{
                background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
                backdropFilter: 'blur(20px)',
              }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2.5 }}>
                    <RefreshCw size={20} color="#1A73E8" />
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>Data & Refresh</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 1 }}>
                    <Box>
                      <Typography variant="body1" sx={{ fontWeight: 500 }}>Auto-Refresh Dashboard</Typography>
                      <Typography variant="caption" sx={{ color: 'text.secondary' }}>Automatically update data at intervals</Typography>
                    </Box>
                    <Switch checked={autoRefresh} onChange={(e) => setAutoRefresh(e.target.checked)} color="primary" />
                  </Box>
                  {autoRefresh && (
                    <Box sx={{ mt: 2, px: 1 }}>
                      <Typography variant="body2" sx={{ mb: 1 }}>
                        Refresh interval: <strong>{refreshInterval}s</strong>
                      </Typography>
                      <Slider
                        value={refreshInterval}
                        onChange={(_, v) => setRefreshInterval(v as number)}
                        min={10} max={120} step={5}
                        marks={[{ value: 30, label: '30s' }, { value: 60, label: '1m' }, { value: 120, label: '2m' }]}
                        sx={{ color: '#C5281C' }}
                      />
                    </Box>
                  )}
                </CardContent>
              </Card>
            </Grid>

            <Grid size={{ xs: 12 }}>
              <Card sx={{
                background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
                backdropFilter: 'blur(20px)',
              }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2.5 }}>
                    <Bell size={20} color="#FFC107" />
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>Notifications</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', py: 1 }}>
                    <Box>
                      <Typography variant="body1" sx={{ fontWeight: 500 }}>Push Notifications</Typography>
                      <Typography variant="caption" sx={{ color: 'text.secondary' }}>Get alerts for test failures and AI insights</Typography>
                    </Box>
                    <Switch checked={notifications} onChange={(e) => setNotifications(e.target.checked)} color="primary" />
                  </Box>
                </CardContent>
              </Card>
            </Grid>

            <Grid size={{ xs: 12 }}>
              <Card sx={{
                background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
                backdropFilter: 'blur(20px)',
              }}>
                <CardContent>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2.5 }}>
                    <Globe size={20} color="#28A745" />
                    <Typography variant="h6" sx={{ fontWeight: 600 }}>General</Typography>
                  </Box>
                  <Grid container spacing={2}>
                    <Grid size={{ xs: 12, sm: 6 }}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Language</InputLabel>
                        <Select value={language} label="Language" onChange={(e) => setLanguage(e.target.value)}>
                          <MenuItem value="en">English</MenuItem>
                          <MenuItem value="de">Deutsch</MenuItem>
                          <MenuItem value="it">Italiano</MenuItem>
                          <MenuItem value="fr">Francais</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid size={{ xs: 12, sm: 6 }}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Default View</InputLabel>
                        <Select value={defaultView} label="Default View" onChange={(e) => setDefaultView(e.target.value)}>
                          <MenuItem value="dashboard">Dashboard</MenuItem>
                          <MenuItem value="execution">Test Execution</MenuItem>
                          <MenuItem value="defects">Defect Tracker</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                  </Grid>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{
            background: (theme) => theme.palette.mode === 'dark' ? 'rgba(30,30,30,0.7)' : 'rgba(255,255,255,0.8)',
            backdropFilter: 'blur(20px)',
            position: 'sticky', top: 80,
          }}>
            <CardContent>
              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', py: 3 }}>
                <Avatar sx={{
                  width: 80, height: 80, fontSize: '2rem', fontWeight: 700, mb: 2,
                  background: 'linear-gradient(135deg, #C5281C 0%, #E05548 100%)',
                  boxShadow: '0 4px 16px rgba(197,40,28,0.3)',
                }}>
                  SC
                </Avatar>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>Sarah Chen</Typography>
                <Typography variant="body2" sx={{ color: 'text.secondary', mb: 1 }}>Senior QE Engineer</Typography>
                <Chip label="Admin" size="small" sx={{ fontWeight: 600, bgcolor: alpha('#C5281C', 0.1), color: '#C5281C', mb: 2 }} />
                <Typography variant="caption" sx={{ color: 'text.secondary', mb: 3 }}>sarah.chen@generali.com</Typography>
                <Divider sx={{ width: '100%', mb: 2 }} />
                <Box sx={{ width: '100%' }}>
                  <Typography variant="subtitle2" sx={{ mb: 1 }}>Active Projects</Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {['Life Insurance', 'Claims Portal', 'Customer App'].map(p => (
                      <Chip key={p} label={p} size="small" variant="outlined" sx={{ fontSize: '0.75rem' }} />
                    ))}
                  </Box>
                </Box>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
