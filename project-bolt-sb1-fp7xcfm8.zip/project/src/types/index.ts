export interface KPIMetric {
  id: string;
  title: string;
  value: string | number;
  change: number;
  changeLabel: string;
  icon: string;
  color: string;
}

export interface TestExecution {
  id: string;
  testCaseId: string;
  testName: string;
  suite: string;
  status: 'passed' | 'failed' | 'running' | 'blocked' | 'skipped';
  duration: string;
  executedBy: string;
  executedAt: string;
  environment: string;
  buildNumber: string;
}

export interface Defect {
  id: string;
  title: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  priority: 'P1' | 'P2' | 'P3' | 'P4';
  status: 'open' | 'in-progress' | 'resolved' | 'closed' | 'reopened';
  assignee: string;
  reporter: string;
  createdAt: string;
  updatedAt: string;
  sprint: string;
  module: string;
}

export interface TestCase {
  id: string;
  title: string;
  module: string;
  priority: 'critical' | 'high' | 'medium' | 'low';
  type: 'functional' | 'regression' | 'smoke' | 'integration' | 'e2e';
  status: 'active' | 'draft' | 'deprecated';
  steps: number;
  lastRun: string;
  lastResult: 'passed' | 'failed' | 'not-run';
  automation: 'automated' | 'manual' | 'semi-automated';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  suggestions?: string[];
}

export interface AIInsight {
  id: string;
  type: 'risk' | 'optimization' | 'anomaly' | 'prediction';
  title: string;
  description: string;
  confidence: number;
  impact: 'high' | 'medium' | 'low';
  timestamp: string;
}

export interface SprintMetric {
  sprint: string;
  passRate: number;
  defectCount: number;
  executionCount: number;
  automationRate: number;
}

export interface TrendData {
  date: string;
  passed: number;
  failed: number;
  skipped: number;
}

export interface UserPreferences {
  darkMode: boolean;
  language: string;
  notifications: boolean;
  autoRefresh: boolean;
  refreshInterval: number;
  defaultView: 'dashboard' | 'execution' | 'defects';
}
