import type { ChatMessage } from '../types';
import * as mockData from '../mock/data';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function fetchMock<T>(data: T, ms = 300): Promise<T> {
  await delay(ms);
  return data;
}

export const api = {
  getKPIs: () => fetchMock(mockData.kpiMetrics),

  getTestExecutions: (filters?: { status?: string; suite?: string }) => {
    let data = mockData.testExecutions;
    if (filters?.status) data = data.filter(e => e.status === filters.status);
    if (filters?.suite) data = data.filter(e => e.suite === filters.suite);
    return fetchMock(data);
  },

  getDefects: (filters?: { severity?: string; status?: string; module?: string }) => {
    let data = mockData.defects;
    if (filters?.severity) data = data.filter(d => d.severity === filters.severity);
    if (filters?.status) data = data.filter(d => d.status === filters.status);
    if (filters?.module) data = data.filter(d => d.module === filters.module);
    return fetchMock(data);
  },

  getTestCases: (filters?: { module?: string; type?: string; automation?: string }) => {
    let data = mockData.testCases;
    if (filters?.module) data = data.filter(tc => tc.module === filters.module);
    if (filters?.type) data = data.filter(tc => tc.type === filters.type);
    if (filters?.automation) data = data.filter(tc => tc.automation === filters.automation);
    return fetchMock(data);
  },

  getAIInsights: () => fetchMock(mockData.aiInsights, 500),

  getSprintMetrics: () => fetchMock(mockData.sprintMetrics),

  getTrendData: () => fetchMock(mockData.trendData),

  getDefectDistribution: () => fetchMock(mockData.defectDistribution),

  sendChatMessage: async (message: string, _history: ChatMessage[]): Promise<ChatMessage> => {
    await delay(800);
    const responses: Record<string, { content: string; suggestions: string[] }> = {
      risk: {
        content: 'Based on current analysis, the **Authentication module** is the highest risk area with a 40% increase in failures over the last 3 builds. The Rating Engine is also flagged with 85% probability of regression in the next deployment.\n\n**Recommended Actions:**\n1. Prioritize DEF-1042 and DEF-1044 for immediate resolution\n2. Increase test coverage for OAuth flow\n3. Schedule a focused regression run before next deployment',
        suggestions: ['Show defect details for DEF-1042', 'What tests cover the Auth module?', 'Generate test cases for OAuth flow'],
      },
      failure: {
        content: 'Recent test failure analysis shows **3 distinct failure clusters**:\n\n1. **Authentication (2 failures)**: Related to special character handling in passwords and session management\n2. **Payments (1 failure)**: Batch processing timeout - likely connection pool exhaustion\n3. **Rating Engine (1 blocked)**: Dependency on unresolved DEF-1044\n\n**Root Cause Confidence:** 87% for Auth issues, 72% for Payment timeout',
        suggestions: ['Show me DEF-1042 details', 'Rerun failed tests', 'What caused the payment timeout?'],
      },
      generate: {
        content: 'I can generate test cases for any module. Here are some suggested test cases for the **Authentication module**:\n\n1. **TC-AUTH-001**: Verify login with SQL injection characters in email field\n2. **TC-AUTH-002**: Validate session timeout after 30 minutes of inactivity\n3. **TC-AUTH-003**: Test concurrent login from multiple devices\n4. **TC-AUTH-004**: Verify password complexity enforcement on reset\n5. **TC-AUTH-005**: Test OAuth token refresh during active session\n\nWould you like me to create these as draft test cases?',
        suggestions: ['Yes, create them as drafts', 'Generate for a different module', 'Show existing Auth test cases'],
      },
      sprint: {
        content: 'For **Sprint 24**, I recommend focusing on:\n\n1. **Critical Path**: Resolve DEF-1042 (Auth) and DEF-1044 (Rating Engine) - these block 8 test cases\n2. **Stability**: The Payment batch timeout needs investigation before the next release\n3. **Quick Wins**: DEF-1048 (session expiry) is reopened and affects user experience\n\n**Predicted Sprint Completion:** 89% pass rate if critical defects are resolved by mid-sprint',
        suggestions: ['Show sprint velocity trend', 'What\'s blocking the most tests?', 'Predict next sprint quality'],
      },
    };

    const lower = message.toLowerCase();
    let match = 'sprint';
    if (lower.includes('risk')) match = 'risk';
    else if (lower.includes('fail')) match = 'failure';
    else if (lower.includes('generat')) match = 'generate';

    const response = responses[match];
    return {
      id: String(Date.now()),
      role: 'assistant',
      content: response.content,
      timestamp: new Date().toISOString(),
      suggestions: response.suggestions,
    };
  },
};
