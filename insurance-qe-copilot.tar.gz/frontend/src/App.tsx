import { useRef, useEffect, useState } from 'react';
import { useChat } from './hooks/useChat';
import { Sidebar } from './components/Sidebar';
import { MessageBubble } from './components/MessageBubble';
import { ChatInput } from './components/ChatInput';
import { EmptyState } from './components/EmptyState';
import { TypingIndicator } from './components/TypingIndicator';
import type { AgentType } from './types';

export default function App() {
  const { messages, loading, send, clear } = useChat();
  const bottomRef = useRef<HTMLDivElement>(null);
  const [activeAgent, setActiveAgent] = useState<AgentType | undefined>();

  // Track last used agent
  useEffect(() => {
    const last = [...messages].reverse().find(m => m.agentUsed);
    if (last?.agentUsed) setActiveAgent(last.agentUsed);
  }, [messages]);

  // Auto-scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleExampleClick = (text: string) => {
    send(text);
  };

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar onExampleClick={handleExampleClick} activeAgent={activeAgent} />

      {/* Main area */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        background: '#0d1b2e',
        overflow: 'hidden',
      }}>
        {/* Top bar */}
        <header style={{
          padding: '14px 24px',
          borderBottom: '1px solid #1e293b',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: '#0d1b2e',
          flexShrink: 0,
        }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#e2e8f0' }}>
              QE Copilot Chat
            </div>
            <div style={{ fontSize: 11, color: '#475569', marginTop: 1 }}>
              LangGraph Supervisor · 5 Specialized Agents · RAG-powered
            </div>
          </div>

          {/* Status dot */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{
              width: 7,
              height: 7,
              borderRadius: '50%',
              background: '#10b981',
              boxShadow: '0 0 6px #10b981',
            }} />
            <span style={{ fontSize: 11, color: '#475569' }}>Qdrant · FastAPI</span>
          </div>
        </header>

        {/* Messages */}
        <div style={{
          flex: 1,
          overflowY: 'auto',
          padding: '20px 24px',
        }}>
          {messages.length === 0 ? (
            <EmptyState onExampleClick={handleExampleClick} />
          ) : (
            <>
              {messages.map(msg => (
                <div key={msg.id} className="message-enter">
                  <MessageBubble message={msg} />
                </div>
              ))}
              {loading && <TypingIndicator />}
              <div ref={bottomRef} />
            </>
          )}
        </div>

        <ChatInput
          onSend={send}
          onClear={clear}
          loading={loading}
          hasMessages={messages.length > 0}
        />
      </div>
    </div>
  );
}
