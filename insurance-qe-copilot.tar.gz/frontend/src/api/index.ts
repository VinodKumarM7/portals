import axios from 'axios';
import type { QueryRequest, QueryResponse } from '../types';

const client = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
  timeout: 60000,
});

export async function sendQuery(payload: QueryRequest): Promise<QueryResponse> {
  const { data } = await client.post<QueryResponse>('/api/query', payload);
  return data;
}

export async function checkHealth(): Promise<boolean> {
  try {
    await client.get('/health');
    return true;
  } catch {
    return false;
  }
}
