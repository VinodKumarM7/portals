export type AgentType = 'requirements' | 'test' | 'coverage' | 'defect' | 'review';

export interface QueryRequest {
  input: string;
}

export interface QueryResponse {
  agent_used: AgentType;
  response: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  agentUsed?: AgentType;
  timestamp: Date;
}

export interface AgentMeta {
  label: string;
  icon: string;
  color: string;
  border: string;
  description: string;
  examples: string[];
}
