import type { Message } from '../types';
import { AgentBadge } from './AgentBadge';

interface Props {
  message: Message;
}

function formatTime(d: Date) {
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatContent(content: string) {
  // Simple markdown-like formatting for numbered lists, bold, code blocks
  const lines = content.split('\n');
  return lines.map((line, i) => {
    // Code block (triple backtick - simplified)
    if (line.startsWith('```')) return null;

    // Bold **text**
    const boldFormatted = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // Numbered list
    const isNumbered = /^\d+\./.test(line);
    // Bullet list
    const isBullet = /^[-•]/.test(line.trim());
    // Heading
    const isH3 = line.startsWith('### ');
    const isH2 = line.startsWith('## ');

    const clean = boldFormatted
      .replace(/^###\s*/, '')
      .replace(/^##\s*/, '')
      .replace(/^[-•]\s*/, '');

    if (isH2 || isH3) {
      return (
        <div key={i} style={{
          fontWeight: 700,
          fontSize: isH2 ? 14 : 13,
          color: '#e2e8f0',
          marginTop: 12,
          marginBottom: 4,
          letterSpacing: '0.01em',
        }}
          dangerouslySetInnerHTML={{ __html: clean }}
        />
      );
    }

    if (isNumbered || isBullet) {
      return (
        <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 4 }}>
          <span style={{ color: '#64748b', minWidth: 20, fontSize: 13 }}>
            {isBullet ? '▸' : line.match(/^\d+/)?.[0] + '.'}
          </span>
          <span
            style={{ fontSize: 13, lineHeight: 1.65, color: '#cbd5e1' }}
            dangerouslySetInnerHTML={{ __html: isNumbered ? boldFormatted.replace(/^\d+\.\s*/, '') : clean }}
          />
        </div>
      );
    }

    if (!line.trim()) return <div key={i} style={{ height: 6 }} />;

    return (
      <div
        key={i}
        style={{ fontSize: 13, lineHeight: 1.7, color: '#cbd5e1', marginBottom: 2 }}
        dangerouslySetInnerHTML={{ __html: boldFormatted }}
      />
    );
  });
}

export function MessageBubble({ message }: Props) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
        <div style={{
          maxWidth: '72%',
          background: 'linear-gradient(135deg, #c21b17, #991410)',
          borderRadius: '18px 18px 4px 18px',
          padding: '12px 16px',
          boxShadow: '0 2px 12px rgba(194,27,23,0.35)',
        }}>
          <p style={{ margin: 0, fontSize: 13, color: '#fff', lineHeight: 1.6 }}>
            {message.content}
          </p>
          <div style={{ textAlign: 'right', marginTop: 4 }}>
            <span style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)' }}>
              {formatTime(message.timestamp)}
            </span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', gap: 10, marginBottom: 20, alignItems: 'flex-start' }}>
      {/* Avatar */}
      <div style={{
        width: 34,
        height: 34,
        borderRadius: '50%',
        background: 'linear-gradient(135deg, #0f172a, #1e293b)',
        border: '1px solid #334155',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 14,
        flexShrink: 0,
        marginTop: 2,
      }}>
        🛡️
      </div>

      <div style={{ maxWidth: '84%', flex: 1 }}>
        {/* Agent badge */}
        {message.agentUsed && (
          <div style={{ marginBottom: 6 }}>
            <AgentBadge agent={message.agentUsed} size="sm" />
          </div>
        )}

        {/* Content */}
        <div style={{
          background: '#1e293b',
          border: '1px solid #334155',
          borderRadius: '4px 18px 18px 18px',
          padding: '14px 16px',
        }}>
          {formatContent(message.content)}
        </div>

        <div style={{ marginTop: 4, paddingLeft: 4 }}>
          <span style={{ fontSize: 10, color: '#475569' }}>
            {formatTime(message.timestamp)}
          </span>
        </div>
      </div>
    </div>
  );
}
