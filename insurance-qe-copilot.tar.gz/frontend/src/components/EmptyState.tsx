import { AGENT_META } from '../utils/agents';
import type { AgentType } from '../types';

interface Props {
  onExampleClick: (text: string) => void;
}

const FEATURED: { agent: AgentType; example: string }[] = [
  { agent: 'requirements', example: 'Extract testable requirements from: A policyholder must be able to add a beneficiary within 30 days of policy issuance' },
  { agent: 'test', example: 'Generate test cases for the auto-renewal feature in a life insurance portal' },
  { agent: 'coverage', example: 'Identify coverage gaps in our smoke test suite for the claims module' },
  { agent: 'defect', example: 'Classify this defect: Premium amount shows $0 for bundled home+auto policies at checkout' },
  { agent: 'review', example: 'Review these test cases and check for GDPR compliance gaps' },
];

export function EmptyState({ onExampleClick }: Props) {
  return (
    <div style={{
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '40px 32px',
      gap: 32,
    }}>
      {/* Hero */}
      <div style={{ textAlign: 'center' }}>
        <div style={{
          width: 64,
          height: 64,
          borderRadius: 18,
          background: 'linear-gradient(135deg, #c21b17, #7c1614)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: 30,
          margin: '0 auto 20px',
          boxShadow: '0 8px 32px rgba(194,27,23,0.45)',
        }}>
          🛡️
        </div>
        <h1 style={{
          margin: '0 0 8px',
          fontSize: 22,
          fontWeight: 700,
          color: '#f1f5f9',
          letterSpacing: '-0.02em',
        }}>
          Insurance QE Copilot
        </h1>
        <p style={{
          margin: 0,
          fontSize: 13,
          color: '#64748b',
          maxWidth: 400,
          lineHeight: 1.6,
        }}>
          AI-powered quality engineering assistant for insurance software teams.
          Ask about requirements, test cases, coverage gaps, defects, or artifact reviews.
        </p>
      </div>

      {/* Quick start cards */}
      <div style={{
        width: '100%',
        maxWidth: 680,
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
        gap: 10,
      }}>
        {FEATURED.map(({ agent, example }) => {
          const meta = AGENT_META[agent];
          return (
            <button
              key={agent}
              onClick={() => onExampleClick(example)}
              style={{
                textAlign: 'left',
                background: '#1e293b',
                border: `1px solid #334155`,
                borderRadius: 12,
                padding: '14px 16px',
                cursor: 'pointer',
                transition: 'all 0.15s',
                display: 'flex',
                flexDirection: 'column',
                gap: 6,
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.borderColor = `${meta.color}60`;
                (e.currentTarget as HTMLElement).style.background = `${meta.color}0a`;
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.borderColor = '#334155';
                (e.currentTarget as HTMLElement).style.background = '#1e293b';
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ fontSize: 14 }}>{meta.icon}</span>
                <span style={{ fontSize: 11, fontWeight: 600, color: meta.color }}>
                  {meta.label}
                </span>
              </div>
              <span style={{ fontSize: 12, color: '#94a3b8', lineHeight: 1.5 }}>
                {example.length > 90 ? example.slice(0, 90) + '…' : example}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
