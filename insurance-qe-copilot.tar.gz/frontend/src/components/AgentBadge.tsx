import type { AgentType } from '../types';
import { AGENT_META } from '../utils/agents';

interface Props {
  agent: AgentType;
  size?: 'sm' | 'md';
}

export function AgentBadge({ agent, size = 'sm' }: Props) {
  const meta = AGENT_META[agent];
  const pad = size === 'sm' ? '2px 8px' : '4px 12px';
  const fs = size === 'sm' ? '11px' : '13px';

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4,
        padding: pad,
        borderRadius: 20,
        fontSize: fs,
        fontWeight: 600,
        fontFamily: 'monospace',
        background: `${meta.color}18`,
        color: meta.color,
        border: `1px solid ${meta.color}40`,
        letterSpacing: '0.02em',
      }}
    >
      {meta.icon} {meta.label}
    </span>
  );
}
