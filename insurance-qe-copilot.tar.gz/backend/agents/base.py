from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

from rag.retriever import get_retriever, collection_exists

MODEL = "claude-sonnet-4-6"


def _format_docs(docs) -> str:
    if not docs:
        return "No relevant documents found in the knowledge base."
    return "\n\n---\n\n".join(
        f"[Source: {d.metadata.get('source', 'unknown')}, p.{d.metadata.get('page', '?')}]\n{d.page_content}"
        for d in docs
    )


def build_agent(system_prompt: str):
    """
    Returns a LangChain chain: input str → str response.
    Uses RAG if Qdrant collection exists, otherwise answers from model knowledge only.
    """
    llm = ChatAnthropic(model=MODEL, max_tokens=1500)
    parser = StrOutputParser()

    if collection_exists():
        retriever = get_retriever()
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt + "\n\n--- Insurance Document Context ---\n{context}\n---"),
            ("human", "{input}"),
        ])
        chain = (
            {"context": retriever | _format_docs, "input": RunnablePassthrough()}
            | prompt
            | llm
            | parser
        )
    else:
        # No documents ingested yet — still useful, just without RAG
        prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt + "\n\n(No insurance documents have been ingested yet. Answer from general knowledge.)"),
            ("human", "{input}"),
        ])
        chain = prompt | llm | parser

    return chain
