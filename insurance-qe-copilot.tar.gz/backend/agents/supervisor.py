import json
import logging
from typing import TypedDict, Literal

from langgraph.graph import StateGraph, END
from langchain_anthropic import ChatAnthropic
from langchain_core.output_parsers import StrOutputParser

from agents.requirements_agent import requirements_agent
from agents.test_agent import test_agent
from agents.coverage_agent import coverage_agent
from agents.defect_agent import defect_agent
from agents.review_agent import review_agent

logger = logging.getLogger(__name__)

AgentName = Literal["requirements", "test", "coverage", "defect", "review"]

ROUTER_SYSTEM = """You are a QE Copilot supervisor for an insurance software team.

Classify the user's request and route it to exactly ONE of these agents:

- "requirements" → The user wants to extract, analyze, or clarify testable requirements 
  from a feature description, user story, or business rule
  
- "test" → The user wants to generate test cases, test scenarios, BDD/Gherkin scenarios, 
  or test scripts for a feature or requirement
  
- "coverage" → The user wants to analyze test coverage gaps, identify missing test scenarios, 
  check boundary value coverage, or assess regulatory coverage
  
- "defect" → The user wants to classify, triage, or analyze a bug/defect/issue, 
  or needs help with root cause analysis or regression test strategy
  
- "review" → The user wants quality review of existing test artifacts (test plans, 
  test cases, test reports), or compliance audit of the test suite

Respond with ONLY a valid JSON object and nothing else:
{"agent": "<agent_name>", "reason": "<one sentence reason>"}
"""


class AgentState(TypedDict):
    input: str
    agent: str
    reason: str
    output: str


def route_node(state: AgentState) -> AgentState:
    """Use the LLM to classify the request and pick an agent."""
    llm = ChatAnthropic(model="claude-sonnet-4-6", max_tokens=100)
    try:
        response = llm.invoke([
            {"role": "system", "content": ROUTER_SYSTEM},
            {"role": "user", "content": state["input"]},
        ])
        parsed = json.loads(response.content)
        agent = parsed.get("agent", "test")
        reason = parsed.get("reason", "")
        logger.info(f"Router → agent='{agent}' reason='{reason}'")
    except (json.JSONDecodeError, Exception) as e:
        logger.warning(f"Router parse error: {e}. Defaulting to 'test' agent.")
        agent = "test"
        reason = "Routing fallback"

    return {**state, "agent": agent, "reason": reason}


def execute_node(state: AgentState) -> AgentState:
    """Invoke the selected agent with the user's input."""
    agents: dict[str, object] = {
        "requirements": requirements_agent,
        "test": test_agent,
        "coverage": coverage_agent,
        "defect": defect_agent,
        "review": review_agent,
    }

    selected = state.get("agent", "test")
    agent = agents.get(selected, test_agent)

    logger.info(f"Executing agent: {selected}")
    try:
        result = agent.invoke(state["input"])
        output = result if isinstance(result, str) else str(result)
    except Exception as e:
        logger.error(f"Agent '{selected}' error: {e}")
        output = f"An error occurred while processing your request: {str(e)}"

    return {**state, "output": output}


def should_execute(state: AgentState) -> Literal["execute", "__end__"]:
    return "execute" if state.get("agent") else END


# Build the LangGraph
_graph = StateGraph(AgentState)
_graph.add_node("route", route_node)
_graph.add_node("execute", execute_node)
_graph.set_entry_point("route")
_graph.add_conditional_edges("route", should_execute, {"execute": "execute", "__end__": END})
_graph.add_edge("execute", END)

supervisor = _graph.compile()


def run(user_input: str) -> dict:
    """
    Public entry point.
    Returns: {"agent_used": str, "response": str}
    """
    initial_state: AgentState = {
        "input": user_input,
        "agent": "",
        "reason": "",
        "output": "",
    }
    result = supervisor.invoke(initial_state)
    return {
        "agent_used": result["agent"],
        "response": result["output"],
    }
