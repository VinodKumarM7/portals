# Insurance QE Copilot — Backend

FastAPI + LangGraph + Qdrant backend for the Insurance QE Copilot.

## Quick Start

```bash
cd backend

# 1. Create virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set up environment
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY

# 4. Start Qdrant (in a separate terminal)
#    Download from: https://github.com/qdrant/qdrant/releases
./qdrant                           # Mac/Linux
qdrant.exe                         # Windows

# 5. (Optional) Ingest insurance documents
python rag/ingest.py path/to/policy.pdf path/to/claims_guide.pdf

# 6. Start the API
uvicorn main:app --reload --port 8000
```

## API Endpoints

| Method | Endpoint       | Description                              |
|--------|---------------|------------------------------------------|
| GET    | /health        | System health check                      |
| GET    | /api/status    | Check if RAG documents are loaded        |
| POST   | /api/query     | Send a question to the QE Copilot        |
| POST   | /api/ingest    | Load insurance documents into Qdrant     |

### POST /api/query
```json
// Request
{ "input": "Generate test cases for the premium calculation feature" }

// Response
{
  "agent_used": "test",
  "response": "TC-001: Premium Calculation — Base Rate..."
}
```

### POST /api/ingest
```json
// Request
{ "file_paths": ["/absolute/path/to/policy_manual.pdf"] }

// Response
{ "chunks_ingested": 142, "message": "Successfully ingested 142 chunks..." }
```

## Architecture

```
FastAPI (main.py)
    │
    ▼
LangGraph Supervisor (agents/supervisor.py)
    │  Routes by intent using Claude
    │
 ┌──┼──────────────────────────────┐
 ▼  ▼        ▼         ▼          ▼
Req  Test  Coverage  Defect    Review
Agent Agent  Agent   Agent     Agent
    │
    ▼
RAG Layer (rag/retriever.py)
    │
    ▼
Qdrant (localhost:6333)
    │
    ▼
Insurance Documents (PDF/TXT)
```

## Agents

| Agent        | Triggered when...                                      |
|-------------|--------------------------------------------------------|
| Requirements | Extracting/analyzing testable requirements             |
| Test         | Generating test cases or BDD scenarios                 |
| Coverage     | Identifying coverage gaps, missing scenarios           |
| Defect       | Triaging bugs, root cause analysis                     |
| Review       | Reviewing test artifacts for quality/compliance        |
