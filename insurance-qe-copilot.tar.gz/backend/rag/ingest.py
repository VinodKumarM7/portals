import os
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_qdrant import QdrantVectorStore
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams

from rag.retriever import get_embeddings, reset_retriever, COLLECTION_NAME, QDRANT_URL


def ingest_documents(file_paths: list[str]) -> int:
    """
    Load, chunk, embed and store documents into Qdrant.
    Returns the number of chunks ingested.
    """
    docs = []
    for path in file_paths:
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")

        ext = os.path.splitext(path)[1].lower()
        if ext == ".pdf":
            loader = PyPDFLoader(path)
        elif ext in (".txt", ".md"):
            loader = TextLoader(path, encoding="utf-8")
        else:
            raise ValueError(f"Unsupported file type: {ext}. Use PDF or TXT.")

        docs.extend(loader.load())

    if not docs:
        raise ValueError("No documents loaded. Check your file paths.")

    # Chunk
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=60,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(docs)

    # Recreate collection
    client = QdrantClient(url=QDRANT_URL)
    client.recreate_collection(
        collection_name=COLLECTION_NAME,
        vectors_config=VectorParams(size=384, distance=Distance.COSINE),
    )

    # Embed + store
    QdrantVectorStore.from_documents(
        documents=chunks,
        embedding=get_embeddings(),
        url=QDRANT_URL,
        collection_name=COLLECTION_NAME,
    )

    # Reset cached retriever so it picks up the new collection
    reset_retriever()

    return len(chunks)


if __name__ == "__main__":
    import sys
    paths = sys.argv[1:] if len(sys.argv) > 1 else ["../docs/sample_policy.pdf"]
    count = ingest_documents(paths)
    print(f"✅ Ingested {count} chunks into '{COLLECTION_NAME}'")
