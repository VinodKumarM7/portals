import os
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_qdrant import QdrantVectorStore
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams

COLLECTION_NAME = os.getenv("QDRANT_COLLECTION", "insurance_docs")
QDRANT_URL = f"http://{os.getenv('QDRANT_HOST', 'localhost')}:{os.getenv('QDRANT_PORT', '6333')}"

# Singleton embeddings model (loaded once at startup)
_embeddings: HuggingFaceEmbeddings | None = None
_retriever = None


def get_embeddings() -> HuggingFaceEmbeddings:
    global _embeddings
    if _embeddings is None:
        _embeddings = HuggingFaceEmbeddings(
            model_name="all-MiniLM-L6-v2",
            model_kwargs={"device": "cpu"},
            encode_kwargs={"normalize_embeddings": True},
        )
    return _embeddings


def get_retriever(k: int = 4):
    """Return a retriever pointed at the insurance_docs collection."""
    global _retriever
    if _retriever is None:
        store = QdrantVectorStore.from_existing_collection(
            embedding=get_embeddings(),
            url=QDRANT_URL,
            collection_name=COLLECTION_NAME,
        )
        _retriever = store.as_retriever(search_kwargs={"k": k})
    return _retriever


def reset_retriever():
    """Call after ingestion so the retriever picks up the new collection."""
    global _retriever
    _retriever = None


def collection_exists() -> bool:
    try:
        client = QdrantClient(url=QDRANT_URL)
        cols = [c.name for c in client.get_collections().collections]
        return COLLECTION_NAME in cols
    except Exception:
        return False
