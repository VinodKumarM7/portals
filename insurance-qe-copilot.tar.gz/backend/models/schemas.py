from pydantic import BaseModel
from typing import Literal

AgentType = Literal["requirements", "test", "coverage", "defect", "review"]


class QueryRequest(BaseModel):
    input: str


class QueryResponse(BaseModel):
    agent_used: AgentType
    response: str


class IngestRequest(BaseModel):
    file_paths: list[str]


class IngestResponse(BaseModel):
    chunks_ingested: int
    message: str


class HealthResponse(BaseModel):
    status: str
    qdrant: str
    anthropic: str
