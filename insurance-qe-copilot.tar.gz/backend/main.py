import logging
import os
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()

from models.schemas import (
    QueryRequest,
    QueryResponse,
    IngestRequest,
    IngestResponse,
    HealthResponse,
)
from agents.supervisor import run as supervisor_run
from rag.retriever import collection_exists
from rag.ingest import ingest_documents

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


# ── Lifespan ────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 Insurance QE Copilot backend starting…")
    if collection_exists():
        logger.info("✅ Qdrant collection found — RAG is active")
    else:
        logger.warning(
            "⚠️  Qdrant collection not found. "
            "Agents will answer without document context. "
            "POST /api/ingest to load insurance documents."
        )
    yield
    logger.info("Backend shutting down.")


# ── App ──────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Insurance QE Copilot API",
    description="AI-powered quality engineering assistant for insurance software teams.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        os.getenv("FRONTEND_URL", "http://localhost:5173"),
        "http://localhost:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Routes ───────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse, tags=["System"])
async def health():
    """Check API, Qdrant and Anthropic connectivity."""
    qdrant_status = "connected" if collection_exists() else "no_collection"

    # Quick Anthropic key check (don't make an actual API call)
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    anthropic_status = "key_present" if api_key.startswith("sk-ant-") else "missing_key"

    return HealthResponse(
        status="ok",
        qdrant=qdrant_status,
        anthropic=anthropic_status,
    )


@app.post("/api/query", response_model=QueryResponse, tags=["Copilot"])
async def query(req: QueryRequest):
    """
    Send a question to the QE Copilot.
    The LangGraph supervisor automatically routes to the correct agent.
    """
    if not req.input.strip():
        raise HTTPException(status_code=400, detail="Input cannot be empty.")

    logger.info(f"Query received: {req.input[:120]}")

    try:
        result = supervisor_run(req.input)
        return QueryResponse(**result)
    except Exception as e:
        logger.error(f"Supervisor error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ingest", response_model=IngestResponse, tags=["RAG"])
async def ingest(req: IngestRequest):
    """
    Ingest insurance documents into Qdrant for RAG.
    Accepts absolute file paths to PDF or TXT files on the server.

    Example:
    {
      "file_paths": ["/path/to/policy_manual.pdf", "/path/to/claims_guide.pdf"]
    }
    """
    if not req.file_paths:
        raise HTTPException(status_code=400, detail="file_paths list cannot be empty.")

    logger.info(f"Ingesting {len(req.file_paths)} file(s)…")

    try:
        count = ingest_documents(req.file_paths)
        return IngestResponse(
            chunks_ingested=count,
            message=f"Successfully ingested {count} chunks from {len(req.file_paths)} file(s).",
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        logger.error(f"Ingest error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/status", tags=["RAG"])
async def rag_status():
    """Check whether the Qdrant collection has documents loaded."""
    has_docs = collection_exists()
    return {
        "rag_active": has_docs,
        "collection": os.getenv("QDRANT_COLLECTION", "insurance_docs"),
        "message": (
            "RAG is active — agents will use insurance documents as context."
            if has_docs
            else "No documents ingested. POST /api/ingest to load insurance documents."
        ),
    }
