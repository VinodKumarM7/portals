import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, TranslateModule],
  template: `
    <div class="dashboard-container">
      <nav class="navbar">
        <div class="navbar-brand">
          <h1>Portal</h1>
        </div>
        <div class="navbar-menu">
          <div class="language-select">
            <label>{{ 'LANGUAGE' | translate }}:</label>
            <select (change)="switchLanguage($event)">
              <option value="en" [selected]="currentLang === 'en'">🇬🇧 English</option>
              <option value="de" [selected]="currentLang === 'de'">🇩🇪 Deutsch</option>
              <option value="es" [selected]="currentLang === 'es'">🇪🇸 Español</option>
              <option value="it" [selected]="currentLang === 'it'">🇮🇹 Italiano</option>
            </select>
          </div>
          <button class="logout-btn" (click)="logout()">Logout</button>
        </div>
      </nav>

      <div class="dashboard-content">
        <div class="welcome-card">
          <h2>Welcome, {{ userInfo?.user.username }}!</h2>
          <p>You have successfully logged in to the portal.</p>
        </div>

        <div class="info-grid">
          <div class="info-card">
            <h3>User Information</h3>
            <div class="info-row">
              <label>Username:</label>
              <span>{{ userInfo?.user.username }}</span>
            </div>
            <div class="info-row">
              <label>Email:</label>
              <span>{{ userInfo?.user.email }}</span>
            </div>
            <div class="info-row">
              <label>User ID:</label>
              <span>{{ userInfo?.user.id }}</span>
            </div>
          </div>

          <div class="info-card">
            <h3>Token Information</h3>
            <div class="info-row">
              <label>Status:</label>
              <span class="token-status">✓ Active</span>
            </div>
            <div class="info-row">
              <label>Storage:</label>
              <span>Secure Cookie</span>
            </div>
            <div class="info-row">
              <label>Token Type:</label>
              <span>JWT Bearer</span>
            </div>
          </div>
        </div>

        <div class="token-display">
          <h3>JWT Token</h3>
          <div class="token-box">
            <code>{{ userInfo?.token }}</code>
            <button class="copy-btn" (click)="copyToClipboard()">Copy</button>
          </div>
          <div class="token-note">
            <p><strong>Note:</strong> Your JWT token is securely stored in an HTTP-only cookie. It's automatically sent with all API requests.</p>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      flex-direction: column;
    }

    .navbar {
      background: rgba(0, 0, 0, 0.1);
      backdrop-filter: blur(10px);
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: white;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .navbar-brand h1 {
      margin: 0;
      font-size: 28px;
      font-weight: 700;
    }

    .navbar-menu {
      display: flex;
      align-items: center;
      gap: 20px;
    }

    .language-select {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .language-select label {
      font-size: 14px;
      color: rgba(255, 255, 255, 0.9);
    }

    .language-select select {
      padding: 8px 12px;
      border: none;
      border-radius: 6px;
      background: rgba(255, 255, 255, 0.95);
      color: #374151;
      font-size: 14px;
      cursor: pointer;
      outline: none;
      transition: all 0.2s;
    }

    .language-select select:hover {
      background: white;
    }

    .logout-btn {
      padding: 10px 20px;
      background: rgba(255, 255, 255, 0.2);
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }

    .logout-btn:hover {
      background: rgba(255, 255, 255, 0.3);
      border-color: rgba(255, 255, 255, 0.5);
    }

    .dashboard-content {
      flex: 1;
      padding: 40px;
      overflow-y: auto;
    }

    .welcome-card {
      background: white;
      border-radius: 12px;
      padding: 30px;
      margin-bottom: 30px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      animation: slideUp 0.5s ease-out;
    }

    .welcome-card h2 {
      color: #1f2937;
      margin: 0 0 10px 0;
      font-size: 24px;
    }

    .welcome-card p {
      color: #6b7280;
      margin: 0;
      font-size: 15px;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .info-card {
      background: white;
      border-radius: 12px;
      padding: 24px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      animation: slideUp 0.5s ease-out 0.1s both;
    }

    .info-card h3 {
      color: #1f2937;
      margin: 0 0 20px 0;
      font-size: 18px;
      border-bottom: 2px solid #f3f4f6;
      padding-bottom: 12px;
    }

    .info-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 0;
      border-bottom: 1px solid #f3f4f6;
    }

    .info-row:last-child {
      border-bottom: none;
    }

    .info-row label {
      color: #6b7280;
      font-weight: 500;
      font-size: 14px;
    }

    .info-row span {
      color: #1f2937;
      font-weight: 600;
      font-size: 14px;
    }

    .token-status {
      color: #10b981 !important;
      background: #d1fae5;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 13px;
    }

    .token-display {
      background: white;
      border-radius: 12px;
      padding: 24px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      animation: slideUp 0.5s ease-out 0.2s both;
    }

    .token-display h3 {
      color: #1f2937;
      margin: 0 0 16px 0;
      font-size: 18px;
      border-bottom: 2px solid #f3f4f6;
      padding-bottom: 12px;
    }

    .token-box {
      background: #1f2937;
      border-radius: 8px;
      padding: 16px;
      position: relative;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
    }

    .token-box code {
      color: #10b981;
      font-family: 'Courier New', monospace;
      font-size: 12px;
      word-break: break-all;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .copy-btn {
      padding: 8px 16px;
      background: #667eea;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      white-space: nowrap;
      transition: background 0.2s;
    }

    .copy-btn:hover {
      background: #5568d3;
    }

    .token-note {
      background: #f0f9ff;
      border-left: 4px solid #667eea;
      padding: 16px;
      border-radius: 6px;
    }

    .token-note p {
      color: #1e40af;
      margin: 0;
      font-size: 14px;
    }

    @media (max-width: 768px) {
      .navbar {
        padding: 16px 20px;
        flex-direction: column;
        gap: 16px;
      }

      .navbar-menu {
        width: 100%;
        justify-content: space-between;
      }

      .dashboard-content {
        padding: 20px;
      }

      .info-grid {
        grid-template-columns: 1fr;
      }

      .token-box {
        flex-direction: column;
        align-items: flex-start;
      }

      .token-box code {
        width: 100%;
      }

      .copy-btn {
        width: 100%;
      }
    }
  `]
})
export class DashboardComponent implements OnInit {
  userInfo: any = null;
  currentLang = 'en';

  constructor(
    private authService: AuthService,
    private router: Router,
    private translate: TranslateService
  ) {}

  ngOnInit(): void {
    this.userInfo = this.authService.getCurrentUser();
    this.currentLang = this.translate.currentLang || 'en';
  }

  switchLanguage(event: Event): void {
    const selectElement = event.target as HTMLSelectElement;
    const lang = selectElement.value;
    this.translate.use(lang);
    this.currentLang = lang;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  copyToClipboard(): void {
    if (this.userInfo?.token) {
      navigator.clipboard.writeText(this.userInfo.token).then(() => {
        alert('Token copied to clipboard!');
      });
    }
  }
}
