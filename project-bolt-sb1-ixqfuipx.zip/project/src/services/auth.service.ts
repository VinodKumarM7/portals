import { Injectable, signal } from '@angular/core';
import { Observable, of, delay, throwError } from 'rxjs';

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: {
    id: string;
    username: string;
    email: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUser = signal<AuthResponse | null>(null);
  private tokenKey = 'jwt_token';
  private cookieName = 'auth_token';

  constructor() {
    const savedToken = this.getTokenFromCookie() || localStorage.getItem(this.tokenKey);
    if (savedToken) {
      try {
        const userData = this.decodeToken(savedToken);
        this.currentUser.set({
          token: savedToken,
          user: userData
        });
      } catch (e) {
        this.clearAuth();
      }
    }
  }

  login(credentials: LoginCredentials): Observable<AuthResponse> {
    if (credentials.username === 'admin' && credentials.password === 'admin123') {
      const mockToken = this.generateMockJWT(credentials.username);
      const response: AuthResponse = {
        token: mockToken,
        user: {
          id: '1',
          username: credentials.username,
          email: `${credentials.username}@example.com`
        }
      };

      this.setTokenInCookie(mockToken);
      localStorage.setItem(this.tokenKey, mockToken);
      this.currentUser.set(response);

      return of(response).pipe(delay(500));
    } else {
      return throwError(() => new Error('Invalid credentials')).pipe(delay(500));
    }
  }

  logout(): void {
    this.clearAuth();
  }

  isAuthenticated(): boolean {
    const hasToken = this.currentUser() !== null;
    const cookieToken = this.getTokenFromCookie();
    return hasToken || !!cookieToken;
  }

  getCurrentUser() {
    return this.currentUser();
  }

  private setTokenInCookie(token: string): void {
    const expirationDate = new Date();
    expirationDate.setTime(expirationDate.getTime() + (24 * 60 * 60 * 1000));
    const expires = `expires=${expirationDate.toUTCString()}`;
    document.cookie = `${this.cookieName}=${token}; ${expires}; path=/; SameSite=Strict`;
  }

  private getTokenFromCookie(): string | null {
    const nameEQ = `${this.cookieName}=`;
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      let cookie = cookies[i].trim();
      if (cookie.indexOf(nameEQ) === 0) {
        return cookie.substring(nameEQ.length);
      }
    }
    return null;
  }

  private clearAuth(): void {
    document.cookie = `${this.cookieName}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
    localStorage.removeItem(this.tokenKey);
    this.currentUser.set(null);
  }

  private generateMockJWT(username: string): string {
    const header = {
      alg: 'HS256',
      typ: 'JWT'
    };

    const payload = {
      sub: '1',
      username: username,
      email: `${username}@example.com`,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + (60 * 60 * 24)
    };

    const base64Header = btoa(JSON.stringify(header));
    const base64Payload = btoa(JSON.stringify(payload));
    const signature = btoa('mock-signature-' + username);

    return `${base64Header}.${base64Payload}.${signature}`;
  }

  private decodeToken(token: string): any {
    const parts = token.split('.');
    if (parts.length !== 3) {
      throw new Error('Invalid token');
    }

    const payload = JSON.parse(atob(parts[1]));
    return {
      id: payload.sub,
      username: payload.username,
      email: payload.email
    };
  }
}
