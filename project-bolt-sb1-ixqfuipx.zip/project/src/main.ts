import { Component } from '@angular/core';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { RouterOutlet } from '@angular/router';
import { provideTranslateService, TranslateService } from '@ngx-translate/core';
import { provideTranslateHttpLoader } from '@ngx-translate/http-loader';
import { routes } from './app.routes';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `<router-outlet></router-outlet>`
})
export class App {
  constructor(private translate: TranslateService) {
    translate.addLangs(['en', 'de', 'es', 'it']);
    translate.setDefaultLang('en');

    const browserLang = translate.getBrowserLang();
    const lang = browserLang && ['en', 'de', 'es', 'it'].includes(browserLang) ? browserLang : 'en';
    translate.use(lang);
  }
}

bootstrapApplication(App, {
  providers: [
    provideHttpClient(),
    provideRouter(routes),
    provideTranslateService({
      loader: provideTranslateHttpLoader()
    })
  ]
});
