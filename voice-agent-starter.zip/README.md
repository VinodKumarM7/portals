# 🎙️ AI Voice Agent — Starter Project

Full-stack multilingual AI voice agent with real-time transcription.

**Stack:** React + TypeScript (Vite) · FastAPI · PostgreSQL · WebSocket

---

## 📁 Project Structure

```
voice-agent/
├── backend/                  # FastAPI Python backend
│   ├── app/
│   │   ├── main.py           # App entry, CORS, routes
│   │   ├── core/
│   │   │   ├── config.py     # Settings (.env driven)
│   │   │   └── security.py   # JWT auth
│   │   ├── db/
│   │   │   └── database.py   # Async SQLAlchemy + session
│   │   ├── models/           # SQLAlchemy models
│   │   │   ├── user.py
│   │   │   ├── session.py
│   │   │   └── transcript.py
│   │   ├── schemas/
│   │   │   └── schemas.py    # Pydantic request/response models
│   │   ├── services/         # Business logic (plug in AI here)
│   │   │   ├── llm_service.py    ← integrate Ollama/OpenAI/Anthropic
│   │   │   ├── stt_service.py    ← integrate Whisper/Deepgram
│   │   │   ├── tts_service.py    ← integrate Edge/Coqui/ElevenLabs
│   │   │   ├── session_service.py
│   │   │   ├── transcript_service.py
│   │   │   └── user_service.py
│   │   └── api/routes/
│   │       ├── auth.py       # /api/auth/*
│   │       ├── sessions.py   # /api/sessions/*
│   │       ├── transcripts.py# /api/transcripts/*
│   │       └── websocket.py  # /ws/voice/{session_id}
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
│
├── frontend/                 # React + TypeScript frontend
│   ├── src/
│   │   ├── pages/
│   │   │   ├── LoginPage.tsx
│   │   │   ├── RegisterPage.tsx
│   │   │   ├── DashboardPage.tsx # Session list
│   │   │   └── SessionPage.tsx   # Live voice chat
│   │   ├── store/
│   │   │   ├── authStore.ts      # Zustand auth state
│   │   │   └── sessionStore.ts   # Session + WS + messages
│   │   ├── services/
│   │   │   ├── api.ts            # Axios client (JWT interceptor)
│   │   │   ├── authService.ts
│   │   │   ├── sessionService.ts
│   │   │   └── wsService.ts      # WebSocket client class
│   │   ├── hooks/
│   │   │   ├── useAudioRecorder.ts  # MediaRecorder → base64 → WS
│   │   │   └── useAudioPlayer.ts    # Web Audio API TTS playback
│   │   └── types/index.ts
│   ├── package.json
│   ├── vite.config.ts
│   ├── Dockerfile
│   └── nginx.conf
│
└── docker-compose.yml
```

---

## 🚀 Quick Start (Local Dev)

### 1. Clone & Configure

```bash
# Backend
cp backend/.env.example backend/.env
# Edit backend/.env — set SECRET_KEY, LLM_PROVIDER, etc.

# Frontend
cp frontend/.env.example frontend/.env
```

### 2. Start Database

```bash
docker compose up postgres -d
```

### 3. Backend

```bash
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs

### 4. Frontend

```bash
cd frontend
npm install
npm run dev
```

App: http://localhost:3000

---

## 🐳 Docker (Full Stack)

```bash
docker compose up --build
```

- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API docs: http://localhost:8000/docs

---

## 🔌 Integrating AI Providers

All AI services are stubbed and ready to activate:

### LLM — `backend/app/services/llm_service.py`

```bash
# Ollama (local)
pip install ollama
# Start Ollama: ollama run llama3.1

# OpenAI
pip install openai
# Set OPENAI_API_KEY in .env

# Anthropic
pip install anthropic
# Set ANTHROPIC_API_KEY in .env
```

### STT — `backend/app/services/stt_service.py`

```bash
# Whisper (local, free, multilingual)
pip install faster-whisper

# Deepgram (streaming, API)
pip install deepgram-sdk
```

### TTS — `backend/app/services/tts_service.py`

```bash
# Edge TTS (free Microsoft voices, 140+ languages)
pip install edge-tts

# Coqui (local, voice cloning)
pip install TTS

# ElevenLabs (highest quality)
pip install elevenlabs
# Set ELEVENLABS_API_KEY in .env
```

Each service file has full commented integration code — just uncomment!

---

## 🌐 WebSocket Protocol

Connect: `ws://localhost:8000/ws/voice/{session_id}?token=<jwt>`

| Client → Server | Payload |
|---|---|
| `audio_chunk` | `{ audio: base64, language: "auto" }` |
| `text_input` | `{ text: "...", language: "en" }` |
| `ping` | `{}` |

| Server → Client | Payload |
|---|---|
| `transcript` | `{ speaker, text, language, confidence }` |
| `llm_chunk` | `{ text: "chunk..." }` |
| `tts_chunk` | `{ audio: base64, format: "mp3" }` |
| `tts_done` | `{}` |
| `status` | `{ message: "..." }` |
| `error` | `{ message: "..." }` |

---

## 📡 REST API

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Get JWT token |
| GET | `/api/auth/me` | Current user |
| POST | `/api/sessions` | Create session |
| GET | `/api/sessions` | List sessions |
| PATCH | `/api/sessions/{id}/end` | End session |
| DELETE | `/api/sessions/{id}` | Delete session |
| GET | `/api/transcripts/{session_id}` | Get transcript |
| GET | `/api/transcripts/{session_id}/export` | Download .txt |

---

## ✅ What's Included

- [x] JWT authentication (register/login)
- [x] Voice session management
- [x] WebSocket real-time pipeline (STT → LLM → TTS)
- [x] Full transcript storage in PostgreSQL
- [x] Transcript export (.txt)
- [x] Multi-language support (10+ languages)
- [x] Pluggable LLM (Ollama / OpenAI / Anthropic)
- [x] Pluggable STT (Whisper / Deepgram / Azure)
- [x] Pluggable TTS (Edge / Coqui / ElevenLabs)
- [x] Docker Compose full-stack deployment
- [x] React frontend with live transcript UI

## 🔜 Next Steps

- [ ] Plug in Ollama / Whisper / Edge TTS
- [ ] Add VAD (Silero) for automatic silence detection
- [ ] Add session title auto-generation via LLM
- [ ] Add language auto-detection display
- [ ] Build mobile-responsive UI improvements
- [ ] Add real-time word-by-word STT streaming
