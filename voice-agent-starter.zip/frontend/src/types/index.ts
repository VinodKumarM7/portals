// ─── Auth ─────────────────────────────────────────────────────────────────────

export interface User {
  id: number
  email: string
  username: string
  full_name: string | null
  preferred_language: string
  is_active: boolean
  created_at: string
}

export interface TokenResponse {
  access_token: string
  token_type: string
  user: User
}

export interface LoginPayload {
  email: string
  password: string
}

export interface RegisterPayload {
  email: string
  username: string
  password: string
  full_name?: string
}

// ─── Sessions ─────────────────────────────────────────────────────────────────

export interface VoiceSession {
  id: number
  user_id: number
  title: string | null
  language: string
  llm_provider: string
  llm_model: string | null
  tts_provider: string
  stt_provider: string
  is_active: boolean
  started_at: string
  ended_at: string | null
}

export interface CreateSessionPayload {
  title?: string
  language?: string
  llm_provider?: string
  llm_model?: string
  tts_provider?: string
  stt_provider?: string
}

// ─── Transcripts ──────────────────────────────────────────────────────────────

export type SpeakerRole = 'user' | 'assistant' | 'system'

export interface TranscriptEntry {
  id: number
  session_id: number
  speaker: SpeakerRole
  text: string
  language: string
  confidence: number | null
  audio_duration_ms: number | null
  llm_provider: string | null
  llm_model: string | null
  created_at: string
}

// ─── WebSocket ────────────────────────────────────────────────────────────────

export type WSEventType =
  | 'transcript'
  | 'llm_chunk'
  | 'tts_chunk'
  | 'tts_done'
  | 'status'
  | 'error'
  | 'pong'

export interface WSEvent {
  type: WSEventType
  payload: Record<string, unknown>
}

// Live message in the chat view (before persisted to DB)
export interface LiveMessage {
  id: string  // temp client ID
  speaker: SpeakerRole
  text: string
  language: string
  isStreaming?: boolean
  timestamp: Date
}

// ─── Config ───────────────────────────────────────────────────────────────────

export type LLMProvider = 'ollama' | 'openai' | 'anthropic'
export type STTProvider = 'whisper' | 'deepgram' | 'azure'
export type TTSProvider = 'edge' | 'coqui' | 'elevenlabs' | 'azure'

export const SUPPORTED_LANGUAGES = [
  { code: 'en', label: 'English' },
  { code: 'de', label: 'Deutsch' },
  { code: 'fr', label: 'Français' },
  { code: 'it', label: 'Italiano' },
  { code: 'es', label: 'Español' },
  { code: 'pt', label: 'Português' },
  { code: 'ja', label: '日本語' },
  { code: 'zh', label: '中文' },
  { code: 'ar', label: 'العربية' },
  { code: 'hi', label: 'हिंदी' },
]
