import { create } from 'zustand'
import type { VoiceSession, LiveMessage, LLMProvider, TTSProvider, STTProvider } from '@/types'
import { sessionService } from '@/services/sessionService'
import { VoiceWebSocket } from '@/services/wsService'
import { nanoid } from '@/utils/nanoid'

interface SessionConfig {
  language: string
  llmProvider: LLMProvider
  llmModel: string
  sttProvider: STTProvider
  ttsProvider: TTSProvider
}

interface SessionState {
  sessions: VoiceSession[]
  activeSession: VoiceSession | null
  messages: LiveMessage[]
  isConnected: boolean
  isRecording: boolean
  isThinking: boolean
  statusText: string
  config: SessionConfig
  ws: VoiceWebSocket | null

  // Actions
  loadSessions: () => Promise<void>
  startSession: (title?: string) => Promise<void>
  endSession: () => Promise<void>
  deleteSession: (id: number) => Promise<void>
  connectWS: (sessionId: number) => Promise<void>
  disconnectWS: () => void
  sendText: (text: string) => void
  addMessage: (msg: Omit<LiveMessage, 'id' | 'timestamp'>) => string
  updateMessage: (id: string, updates: Partial<LiveMessage>) => void
  setConfig: (config: Partial<SessionConfig>) => void
  setRecording: (val: boolean) => void
}

export const useSessionStore = create<SessionState>((set, get) => ({
  sessions: [],
  activeSession: null,
  messages: [],
  isConnected: false,
  isRecording: false,
  isThinking: false,
  statusText: 'Ready',
  ws: null,
  config: {
    language: 'en',
    llmProvider: 'ollama',
    llmModel: 'llama3.1',
    sttProvider: 'whisper',
    ttsProvider: 'edge',
  },

  loadSessions: async () => {
    const sessions = await sessionService.list()
    set({ sessions })
  },

  startSession: async (title) => {
    const { config } = get()
    const session = await sessionService.create({
      title,
      language: config.language,
      llm_provider: config.llmProvider,
      llm_model: config.llmModel,
      stt_provider: config.sttProvider,
      tts_provider: config.ttsProvider,
    })
    set((s) => ({ activeSession: session, sessions: [session, ...s.sessions], messages: [] }))
    await get().connectWS(session.id)
  },

  endSession: async () => {
    const { activeSession } = get()
    if (!activeSession) return
    get().disconnectWS()
    await sessionService.end(activeSession.id)
    set((s) => ({
      activeSession: null,
      sessions: s.sessions.map((ss) =>
        ss.id === activeSession.id ? { ...ss, is_active: false } : ss
      ),
    }))
  },

  deleteSession: async (id) => {
    await sessionService.delete(id)
    set((s) => ({ sessions: s.sessions.filter((ss) => ss.id !== id) }))
  },

  connectWS: async (sessionId) => {
    const ws = new VoiceWebSocket(sessionId)

    // Register event handlers
    ws.on('status', (p) => set({ statusText: (p.message as string) || 'Ready' }))
    ws.on('error', (p) => set({ statusText: `Error: ${p.message}` }))

    ws.on('transcript', (p) => {
      const id = nanoid()
      set((s) => ({
        messages: [
          ...s.messages,
          {
            id,
            speaker: p.speaker as 'user' | 'assistant',
            text: p.text as string,
            language: (p.language as string) || 'en',
            isStreaming: false,
            timestamp: new Date(),
          },
        ],
        isThinking: false,
      }))
    })

    ws.on('llm_chunk', () => {
      set({ isThinking: true })
    })

    ws.on('tts_done', () => {
      set({ isThinking: false })
    })

    await ws.connect()
    set({ ws, isConnected: true })
  },

  disconnectWS: () => {
    get().ws?.disconnect()
    set({ ws: null, isConnected: false })
  },

  sendText: (text) => {
    const { ws, config } = get()
    ws?.sendText(text, config.language, config.llmProvider)
  },

  addMessage: (msg) => {
    const id = nanoid()
    set((s) => ({
      messages: [...s.messages, { ...msg, id, timestamp: new Date() }],
    }))
    return id
  },

  updateMessage: (id, updates) => {
    set((s) => ({
      messages: s.messages.map((m) => (m.id === id ? { ...m, ...updates } : m)),
    }))
  },

  setConfig: (config) => set((s) => ({ config: { ...s.config, ...config } })),
  setRecording: (val) => set({ isRecording: val }),
}))
