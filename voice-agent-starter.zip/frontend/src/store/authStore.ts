import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { User } from '@/types'
import { authService } from '@/services/authService'

interface AuthState {
  user: User | null
  token: string | null
  isLoading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<void>
  register: (email: string, username: string, password: string, fullName?: string) => Promise<void>
  logout: () => void
  clearError: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isLoading: false,
      error: null,

      login: async (email, password) => {
        set({ isLoading: true, error: null })
        try {
          const res = await authService.login({ email, password })
          localStorage.setItem('access_token', res.access_token)
          set({ user: res.user, token: res.access_token, isLoading: false })
        } catch (err: unknown) {
          const msg = (err as { response?: { data?: { detail?: string } } })
            ?.response?.data?.detail || 'Login failed'
          set({ error: msg, isLoading: false })
        }
      },

      register: async (email, username, password, fullName) => {
        set({ isLoading: true, error: null })
        try {
          const res = await authService.register({ email, username, password, full_name: fullName })
          localStorage.setItem('access_token', res.access_token)
          set({ user: res.user, token: res.access_token, isLoading: false })
        } catch (err: unknown) {
          const msg = (err as { response?: { data?: { detail?: string } } })
            ?.response?.data?.detail || 'Registration failed'
          set({ error: msg, isLoading: false })
        }
      },

      logout: () => {
        localStorage.removeItem('access_token')
        set({ user: null, token: null })
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({ user: state.user, token: state.token }),
    }
  )
)
