import { useRef, useCallback } from 'react'
import { useSessionStore } from '@/store/sessionStore'

export function useAudioRecorder() {
  const mediaRecorder = useRef<MediaRecorder | null>(null)
  const audioChunks = useRef<Blob[]>([])
  const { ws, config, setRecording } = useSessionStore()

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const recorder = new MediaRecorder(stream, { mimeType: 'audio/webm;codecs=opus' })

      audioChunks.current = []

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunks.current.push(e.data)
      }

      recorder.onstop = async () => {
        const blob = new Blob(audioChunks.current, { type: 'audio/webm' })
        const arrayBuffer = await blob.arrayBuffer()
        const base64 = btoa(
          new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), '')
        )
        ws?.sendAudio(base64, config.language, config.llmProvider)
        // Stop all tracks to release mic
        stream.getTracks().forEach((t) => t.stop())
      }

      recorder.start()
      mediaRecorder.current = recorder
      setRecording(true)
    } catch (err) {
      console.error('Mic access denied:', err)
    }
  }, [ws, config, setRecording])

  const stopRecording = useCallback(() => {
    mediaRecorder.current?.stop()
    mediaRecorder.current = null
    setRecording(false)
  }, [setRecording])

  const toggleRecording = useCallback(
    (isRecording: boolean) => {
      if (isRecording) stopRecording()
      else startRecording()
    },
    [startRecording, stopRecording]
  )

  return { startRecording, stopRecording, toggleRecording }
}
