import { useRef, useCallback } from 'react'

export function useAudioPlayer() {
  const audioCtx = useRef<AudioContext | null>(null)
  const queue = useRef<ArrayBuffer[]>([])
  const isPlaying = useRef(false)

  const getCtx = () => {
    if (!audioCtx.current) audioCtx.current = new AudioContext()
    return audioCtx.current
  }

  const playNext = useCallback(async () => {
    if (isPlaying.current || queue.current.length === 0) return
    isPlaying.current = true

    const ctx = getCtx()
    const chunk = queue.current.shift()!

    try {
      const buffer = await ctx.decodeAudioData(chunk)
      const source = ctx.createBufferSource()
      source.buffer = buffer
      source.connect(ctx.destination)
      source.onended = () => {
        isPlaying.current = false
        playNext()
      }
      source.start()
    } catch {
      isPlaying.current = false
      playNext()
    }
  }, [])

  const enqueueAudio = useCallback(
    (base64: string) => {
      const binary = atob(base64)
      const bytes = new Uint8Array(binary.length)
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i)
      queue.current.push(bytes.buffer)
      playNext()
    },
    [playNext]
  )

  const clearQueue = useCallback(() => {
    queue.current = []
    isPlaying.current = false
  }, [])

  return { enqueueAudio, clearQueue }
}
