import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Mic, Plus, Trash2, LogOut, Clock, Zap } from 'lucide-react'
import { useAuthStore } from '@/store/authStore'
import { useSessionStore } from '@/store/sessionStore'
import { format } from 'date-fns'
import styles from './DashboardPage.module.css'

export default function DashboardPage() {
  const { user, logout } = useAuthStore()
  const { sessions, loadSessions, startSession, deleteSession } = useSessionStore()
  const navigate = useNavigate()
  const [isCreating, setIsCreating] = useState(false)

  useEffect(() => { loadSessions() }, [loadSessions])

  async function handleNewSession() {
    setIsCreating(true)
    await startSession()
    const session = useSessionStore.getState().activeSession
    if (session) navigate(`/session/${session.id}`)
    setIsCreating(false)
  }

  return (
    <div className={styles.page}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.brand}>
          <Mic size={20} />
          <span>VoiceAgent</span>
        </div>

        <button className={styles.newBtn} onClick={handleNewSession} disabled={isCreating}>
          <Plus size={16} />
          {isCreating ? 'Starting…' : 'New Session'}
        </button>

        <nav className={styles.nav}>
          <p className={styles.navLabel}>Recent Sessions</p>
          {sessions.length === 0 && (
            <p className={styles.empty}>No sessions yet</p>
          )}
          {sessions.map((s) => (
            <div key={s.id} className={styles.sessionItem}>
              <button
                className={styles.sessionBtn}
                onClick={() => navigate(`/session/${s.id}`)}
              >
                <span className={`${styles.dot} ${s.is_active ? styles.dotActive : ''}`} />
                <span className={styles.sessionTitle}>
                  {s.title || `Session ${s.id}`}
                </span>
                <span className={styles.sessionTime}>
                  {format(new Date(s.started_at), 'MMM d')}
                </span>
              </button>
              <button
                className={styles.deleteBtn}
                onClick={() => deleteSession(s.id)}
                title="Delete session"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
        </nav>

        <button className={styles.logoutBtn} onClick={logout}>
          <LogOut size={14} />
          Sign out
        </button>
      </aside>

      {/* Main */}
      <main className={styles.main}>
        <div className={styles.hero}>
          <div className={styles.heroGlow} />
          <div className={styles.heroIcon}>
            <Mic size={40} />
          </div>
          <h1>Welcome back, {user?.full_name || user?.username}</h1>
          <p>Start a voice session or pick up where you left off.</p>

          <button className={styles.startBtn} onClick={handleNewSession} disabled={isCreating}>
            <Mic size={18} />
            {isCreating ? 'Starting session…' : 'Start New Session'}
          </button>

          <div className={styles.features}>
            <div className={styles.feature}>
              <Zap size={18} />
              <span>Multi-LLM</span>
              <small>Ollama · OpenAI · Anthropic</small>
            </div>
            <div className={styles.feature}>
              <Mic size={18} />
              <span>Voice STT</span>
              <small>Whisper · Deepgram</small>
            </div>
            <div className={styles.feature}>
              <Clock size={18} />
              <span>Transcripts</span>
              <small>Full history export</small>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
