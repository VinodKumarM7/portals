import type { WSEvent, WSEventType } from '@/types'

type EventHandler = (payload: Record<string, unknown>) => void

export class VoiceWebSocket {
  private ws: WebSocket | null = null
  private handlers: Map<WSEventType, EventHandler[]> = new Map()
  private sessionId: number
  private reconnectAttempts = 0
  private maxReconnects = 3

  constructor(sessionId: number) {
    this.sessionId = sessionId
  }

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      const token = localStorage.getItem('access_token')
      const wsBase = import.meta.env.VITE_WS_URL || 'ws://localhost:8000'
      const url = `${wsBase}/ws/voice/${this.sessionId}?token=${token}`

      this.ws = new WebSocket(url)

      this.ws.onopen = () => {
        this.reconnectAttempts = 0
        resolve()
      }

      this.ws.onerror = (err) => {
        reject(err)
      }

      this.ws.onmessage = (event) => {
        try {
          const msg: WSEvent = JSON.parse(event.data)
          const handlers = this.handlers.get(msg.type) || []
          handlers.forEach((h) => h(msg.payload || {}))
        } catch (e) {
          console.error('WS parse error', e)
        }
      }

      this.ws.onclose = (event) => {
        if (!event.wasClean && this.reconnectAttempts < this.maxReconnects) {
          this.reconnectAttempts++
          setTimeout(() => this.connect(), 1500 * this.reconnectAttempts)
        }
      }
    })
  }

  on(type: WSEventType, handler: EventHandler): () => void {
    if (!this.handlers.has(type)) this.handlers.set(type, [])
    this.handlers.get(type)!.push(handler)
    // Return unsubscribe fn
    return () => {
      const list = this.handlers.get(type) || []
      this.handlers.set(type, list.filter((h) => h !== handler))
    }
  }

  send(type: string, payload?: Record<string, unknown>) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, payload }))
    }
  }

  sendAudio(audioBase64: string, language = 'auto', llmProvider?: string) {
    this.send('audio_chunk', { audio: audioBase64, language, llm_provider: llmProvider })
  }

  sendText(text: string, language = 'en', llmProvider?: string) {
    this.send('text_input', { text, language, llm_provider: llmProvider })
  }

  ping() {
    this.send('ping')
  }

  disconnect() {
    this.ws?.close(1000, 'User disconnected')
    this.ws = null
  }

  get isConnected() {
    return this.ws?.readyState === WebSocket.OPEN
  }
}
