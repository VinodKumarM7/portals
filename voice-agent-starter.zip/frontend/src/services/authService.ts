import api from './api'
import type { LoginPayload, RegisterPayload, TokenResponse, User } from '@/types'

export const authService = {
  async login(payload: LoginPayload): Promise<TokenResponse> {
    const { data } = await api.post<TokenResponse>('/api/auth/login', payload)
    return data
  },

  async register(payload: RegisterPayload): Promise<TokenResponse> {
    const { data } = await api.post<TokenResponse>('/api/auth/register', payload)
    return data
  },

  async getMe(): Promise<User> {
    const { data } = await api.get<User>('/api/auth/me')
    return data
  },
}
