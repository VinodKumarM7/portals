import api from './api'
import type { VoiceSession, CreateSessionPayload, TranscriptEntry } from '@/types'

export const sessionService = {
  async create(payload: CreateSessionPayload): Promise<VoiceSession> {
    const { data } = await api.post<VoiceSession>('/api/sessions', payload)
    return data
  },

  async list(): Promise<VoiceSession[]> {
    const { data } = await api.get<VoiceSession[]>('/api/sessions')
    return data
  },

  async get(id: number): Promise<VoiceSession> {
    const { data } = await api.get<VoiceSession>(`/api/sessions/${id}`)
    return data
  },

  async end(id: number): Promise<VoiceSession> {
    const { data } = await api.patch<VoiceSession>(`/api/sessions/${id}/end`)
    return data
  },

  async delete(id: number): Promise<void> {
    await api.delete(`/api/sessions/${id}`)
  },
}

export const transcriptService = {
  async list(sessionId: number): Promise<TranscriptEntry[]> {
    const { data } = await api.get<TranscriptEntry[]>(`/api/transcripts/${sessionId}`)
    return data
  },

  exportUrl(sessionId: number): string {
    const token = localStorage.getItem('access_token')
    return `${import.meta.env.VITE_API_URL || 'http://localhost:8000'}/api/transcripts/${sessionId}/export?token=${token}`
  },
}
