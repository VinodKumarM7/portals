"""
LLM Service — Stub ready for integration.

Providers to integrate:
  - ollama:     http://localhost:11434  (LLaMA 3, Mistral, Phi-3, etc.)
  - openai:     OpenAI GPT-4o / GPT-4
  - anthropic:  Claude Sonnet / Haiku

Each provider should implement stream_response() returning an async generator
that yields text chunks for real-time WebSocket streaming.
"""
from typing import AsyncGenerator, List, Dict
from app.core.config import settings


async def stream_response(
    messages: List[Dict[str, str]],
    provider: str = None,
    model: str = None,
) -> AsyncGenerator[str, None]:
    """
    Stream LLM response chunks.
    messages: [{"role": "user"|"assistant"|"system", "content": "..."}]
    """
    provider = provider or settings.LLM_PROVIDER

    if provider == "ollama":
        async for chunk in _stream_ollama(messages, model or settings.OLLAMA_MODEL):
            yield chunk

    elif provider == "openai":
        async for chunk in _stream_openai(messages, model or "gpt-4o"):
            yield chunk

    elif provider == "anthropic":
        async for chunk in _stream_anthropic(messages, model or "claude-sonnet-4-20250514"):
            yield chunk

    else:
        # Fallback stub response
        yield f"[LLM provider '{provider}' not yet integrated. Configure in .env]"


async def _stream_ollama(messages: List[Dict], model: str) -> AsyncGenerator[str, None]:
    """
    TODO: Integrate Ollama
    pip install ollama
    
    import ollama
    async for chunk in await ollama.AsyncClient().chat(
        model=model,
        messages=messages,
        stream=True,
    ):
        yield chunk['message']['content']
    """
    yield f"[Ollama/{model} stub — install ollama and uncomment integration code]"


async def _stream_openai(messages: List[Dict], model: str) -> AsyncGenerator[str, None]:
    """
    TODO: Integrate OpenAI
    pip install openai
    
    from openai import AsyncOpenAI
    client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
    stream = await client.chat.completions.create(
        model=model, messages=messages, stream=True
    )
    async for chunk in stream:
        if chunk.choices[0].delta.content:
            yield chunk.choices[0].delta.content
    """
    yield f"[OpenAI/{model} stub — set OPENAI_API_KEY and uncomment integration code]"


async def _stream_anthropic(messages: List[Dict], model: str) -> AsyncGenerator[str, None]:
    """
    TODO: Integrate Anthropic
    pip install anthropic
    
    import anthropic
    client = anthropic.AsyncAnthropic(api_key=settings.ANTHROPIC_API_KEY)
    async with client.messages.stream(
        model=model, max_tokens=1024, messages=messages
    ) as stream:
        async for text in stream.text_stream:
            yield text
    """
    yield f"[Anthropic/{model} stub — set ANTHROPIC_API_KEY and uncomment integration code]"
