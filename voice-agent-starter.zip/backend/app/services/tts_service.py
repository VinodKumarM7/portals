"""
TTS Service — Stub ready for integration.

Providers to integrate:
  - edge:       Edge TTS (free Microsoft voices, 140+ languages)
  - coqui:      Coqui XTTS v2 (local, voice cloning)
  - elevenlabs: ElevenLabs API (highest quality)
  - kokoro:     Kokoro TTS (fast, lightweight, open)
"""
from typing import AsyncGenerator
from app.core.config import settings


async def synthesize_speech(text: str, language: str = "en") -> AsyncGenerator[bytes, None]:
    """
    Stream TTS audio chunks for real-time playback.
    Yields raw audio bytes (MP3 or PCM).
    """
    provider = settings.TTS_PROVIDER

    if provider == "edge":
        async for chunk in _synthesize_edge(text, language):
            yield chunk
    elif provider == "elevenlabs":
        async for chunk in _synthesize_elevenlabs(text, language):
            yield chunk
    elif provider == "coqui":
        async for chunk in _synthesize_coqui(text, language):
            yield chunk
    else:
        yield b""  # silent fallback


async def _synthesize_edge(text: str, language: str) -> AsyncGenerator[bytes, None]:
    """
    TODO: Integrate Edge TTS
    pip install edge-tts

    import edge_tts, io
    
    VOICE_MAP = {
        "en": "en-US-AriaNeural",
        "de": "de-DE-KatjaNeural",
        "fr": "fr-FR-DeniseNeural",
        "it": "it-IT-ElsaNeural",
        "es": "es-ES-ElviraNeural",
    }
    voice = VOICE_MAP.get(language, "en-US-AriaNeural")
    communicate = edge_tts.Communicate(text, voice)
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            yield chunk["data"]
    """
    yield b""  # stub


async def _synthesize_elevenlabs(text: str, language: str) -> AsyncGenerator[bytes, None]:
    """
    TODO: Integrate ElevenLabs
    pip install elevenlabs
    """
    yield b""  # stub


async def _synthesize_coqui(text: str, language: str) -> AsyncGenerator[bytes, None]:
    """
    TODO: Integrate Coqui XTTS
    pip install TTS
    """
    yield b""  # stub
