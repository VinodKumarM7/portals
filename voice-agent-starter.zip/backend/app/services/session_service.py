from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
from datetime import datetime

from app.models.session import VoiceSession
from app.schemas.schemas import SessionCreate, SessionUpdate


async def create_session(db: AsyncSession, user_id: int, data: SessionCreate) -> VoiceSession:
    session = VoiceSession(
        user_id=user_id,
        title=data.title or f"Session {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}",
        language=data.language,
        llm_provider=data.llm_provider,
        llm_model=data.llm_model,
        tts_provider=data.tts_provider,
        stt_provider=data.stt_provider,
    )
    db.add(session)
    await db.flush()
    await db.refresh(session)
    return session


async def get_sessions(db: AsyncSession, user_id: int) -> List[VoiceSession]:
    result = await db.execute(
        select(VoiceSession)
        .where(VoiceSession.user_id == user_id)
        .order_by(VoiceSession.started_at.desc())
    )
    return result.scalars().all()


async def get_session(db: AsyncSession, session_id: int, user_id: int) -> Optional[VoiceSession]:
    result = await db.execute(
        select(VoiceSession).where(
            VoiceSession.id == session_id,
            VoiceSession.user_id == user_id,
        )
    )
    return result.scalar_one_or_none()


async def end_session(db: AsyncSession, session_id: int, user_id: int) -> Optional[VoiceSession]:
    session = await get_session(db, session_id, user_id)
    if session:
        session.is_active = False
        session.ended_at = datetime.utcnow()
        await db.flush()
        await db.refresh(session)
    return session


async def delete_session(db: AsyncSession, session_id: int, user_id: int) -> bool:
    session = await get_session(db, session_id, user_id)
    if session:
        await db.delete(session)
        return True
    return False
