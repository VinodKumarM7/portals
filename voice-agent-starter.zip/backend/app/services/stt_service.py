"""
STT Service — Stub ready for integration.

Providers to integrate:
  - whisper:   faster-whisper (local, multilingual, best open-source)
  - deepgram:  Real-time streaming STT API
  - azure:     Azure Cognitive Speech Services
"""
from typing import Optional
from app.core.config import settings


class STTResult:
    def __init__(self, text: str, language: str, confidence: Optional[float] = None):
        self.text = text
        self.language = language
        self.confidence = confidence


async def transcribe_audio(audio_bytes: bytes, language: str = "auto") -> STTResult:
    """
    Transcribe audio bytes to text.
    audio_bytes: raw PCM 16-bit / WebM Opus audio
    language: ISO 639-1 code or "auto" for detection
    """
    provider = settings.STT_PROVIDER

    if provider == "whisper":
        return await _transcribe_whisper(audio_bytes, language)
    elif provider == "deepgram":
        return await _transcribe_deepgram(audio_bytes, language)
    else:
        return STTResult(text="[STT not yet integrated]", language="en", confidence=None)


async def _transcribe_whisper(audio_bytes: bytes, language: str) -> STTResult:
    """
    TODO: Integrate faster-whisper
    pip install faster-whisper

    from faster_whisper import WhisperModel
    model = WhisperModel(settings.WHISPER_MODEL, device="cpu", compute_type="int8")
    
    # Save bytes to temp file, then transcribe
    import tempfile, os
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(audio_bytes)
        tmp_path = f.name
    
    segments, info = model.transcribe(tmp_path, language=None if language=="auto" else language)
    text = " ".join([s.text for s in segments])
    os.unlink(tmp_path)
    
    return STTResult(text=text, language=info.language, confidence=info.language_probability)
    """
    return STTResult(
        text="[Whisper stub — pip install faster-whisper and uncomment integration]",
        language="en",
        confidence=None,
    )


async def _transcribe_deepgram(audio_bytes: bytes, language: str) -> STTResult:
    """
    TODO: Integrate Deepgram
    pip install deepgram-sdk
    """
    return STTResult(
        text="[Deepgram stub — set DEEPGRAM_API_KEY and uncomment integration]",
        language="en",
    )
