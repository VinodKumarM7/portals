from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List

from app.models.transcript import Transcript
from app.schemas.schemas import TranscriptCreate


async def create_transcript(db: AsyncSession, data: TranscriptCreate) -> Transcript:
    transcript = Transcript(**data.model_dump())
    db.add(transcript)
    await db.flush()
    await db.refresh(transcript)
    return transcript


async def get_transcripts_by_session(
    db: AsyncSession, session_id: int
) -> List[Transcript]:
    result = await db.execute(
        select(Transcript)
        .where(Transcript.session_id == session_id)
        .order_by(Transcript.created_at.asc())
    )
    return result.scalars().all()


async def export_transcript_text(db: AsyncSession, session_id: int) -> str:
    transcripts = await get_transcripts_by_session(db, session_id)
    lines = []
    for t in transcripts:
        ts = t.created_at.strftime("%H:%M:%S")
        speaker = "You" if t.speaker == "user" else "Assistant"
        lines.append(f"[{ts}] {speaker} ({t.language}): {t.text}")
    return "\n".join(lines)
