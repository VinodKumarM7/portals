import json
import base64
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from jose import JWTError, jwt

from app.core.config import settings
from app.core.security import get_password_hash
from app.services.llm_service import stream_response
from app.services.stt_service import transcribe_audio
from app.services.tts_service import synthesize_speech

router = APIRouter()

# Track active connections: session_id -> WebSocket
active_connections: dict[int, WebSocket] = {}


async def authenticate_ws(token: str) -> int | None:
    """Validate JWT and return user_id or None."""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id = payload.get("sub")
        return int(user_id) if user_id else None
    except JWTError:
        return None


async def send_event(ws: WebSocket, event_type: str, payload: dict):
    await ws.send_text(json.dumps({"type": event_type, "payload": payload}))


@router.websocket("/voice/{session_id}")
async def voice_websocket(
    websocket: WebSocket,
    session_id: int,
    token: str = Query(...),
):
    # Authenticate
    user_id = await authenticate_ws(token)
    if not user_id:
        await websocket.close(code=4001, reason="Unauthorized")
        return

    await websocket.accept()
    active_connections[session_id] = websocket

    # Conversation history for LLM context
    conversation: list[dict] = [
        {
            "role": "system",
            "content": (
                "You are a helpful multilingual voice assistant. "
                "Respond concisely and naturally, as your response will be spoken aloud. "
                "Detect the language the user speaks and always reply in the same language."
            ),
        }
    ]

    await send_event(websocket, "status", {"message": "Connected", "session_id": session_id})

    try:
        while True:
            raw = await websocket.receive_text()
            message = json.loads(raw)
            msg_type = message.get("type")
            payload = message.get("payload", {})

            # ── Ping ────────────────────────────────────────────────────────
            if msg_type == "ping":
                await send_event(websocket, "pong", {})

            # ── Audio chunk → STT → LLM → TTS ───────────────────────────────
            elif msg_type == "audio_chunk":
                audio_b64 = payload.get("audio")
                language = payload.get("language", "auto")
                if not audio_b64:
                    continue

                audio_bytes = base64.b64decode(audio_b64)

                # 1. STT
                await send_event(websocket, "status", {"message": "Transcribing..."})
                stt_result = await transcribe_audio(audio_bytes, language)

                if not stt_result.text.strip():
                    await send_event(websocket, "status", {"message": "No speech detected"})
                    continue

                # 2. Emit user transcript
                await send_event(websocket, "transcript", {
                    "speaker": "user",
                    "text": stt_result.text,
                    "language": stt_result.language,
                    "confidence": stt_result.confidence,
                })

                # 3. Add to conversation
                conversation.append({"role": "user", "content": stt_result.text})

                # 4. LLM stream
                await send_event(websocket, "status", {"message": "Thinking..."})
                llm_text = ""
                provider = payload.get("llm_provider", settings.LLM_PROVIDER)
                model = payload.get("llm_model")

                async for chunk in stream_response(conversation, provider, model):
                    llm_text += chunk
                    await send_event(websocket, "llm_chunk", {"text": chunk})

                # 5. Emit full assistant transcript
                conversation.append({"role": "assistant", "content": llm_text})
                await send_event(websocket, "transcript", {
                    "speaker": "assistant",
                    "text": llm_text,
                    "language": stt_result.language,
                    "llm_provider": provider,
                    "llm_model": model,
                })

                # 6. TTS → stream audio back
                await send_event(websocket, "status", {"message": "Synthesizing speech..."})
                audio_chunks = []
                async for audio_chunk in synthesize_speech(llm_text, stt_result.language):
                    if audio_chunk:
                        audio_chunks.append(audio_chunk)
                        await send_event(websocket, "tts_chunk", {
                            "audio": base64.b64encode(audio_chunk).decode(),
                            "format": "mp3",
                        })

                await send_event(websocket, "tts_done", {})
                await send_event(websocket, "status", {"message": "Ready"})

            # ── Text input (no audio) → LLM → TTS ───────────────────────────
            elif msg_type == "text_input":
                text = payload.get("text", "").strip()
                language = payload.get("language", "en")
                if not text:
                    continue

                await send_event(websocket, "transcript", {
                    "speaker": "user",
                    "text": text,
                    "language": language,
                })

                conversation.append({"role": "user", "content": text})

                llm_text = ""
                provider = payload.get("llm_provider", settings.LLM_PROVIDER)
                model = payload.get("llm_model")

                async for chunk in stream_response(conversation, provider, model):
                    llm_text += chunk
                    await send_event(websocket, "llm_chunk", {"text": chunk})

                conversation.append({"role": "assistant", "content": llm_text})
                await send_event(websocket, "transcript", {
                    "speaker": "assistant",
                    "text": llm_text,
                    "language": language,
                    "llm_provider": provider,
                })

                async for audio_chunk in synthesize_speech(llm_text, language):
                    if audio_chunk:
                        await send_event(websocket, "tts_chunk", {
                            "audio": base64.b64encode(audio_chunk).decode(),
                            "format": "mp3",
                        })
                await send_event(websocket, "tts_done", {})
                await send_event(websocket, "status", {"message": "Ready"})

            # ── Config update ─────────────────────────────────────────────────
            elif msg_type == "config":
                await send_event(websocket, "status", {
                    "message": "Config updated",
                    "config": payload,
                })

    except WebSocketDisconnect:
        active_connections.pop(session_id, None)
    except Exception as e:
        await send_event(websocket, "error", {"message": str(e)})
        active_connections.pop(session_id, None)
