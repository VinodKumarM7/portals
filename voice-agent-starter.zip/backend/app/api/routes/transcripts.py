from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.db.database import get_db
from app.core.security import get_current_user
from app.models.user import User
from app.schemas.schemas import TranscriptResponse
from app.services import transcript_service, session_service

router = APIRouter()


@router.get("/{session_id}", response_model=List[TranscriptResponse])
async def get_transcripts(
    session_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Verify session belongs to user
    session = await session_service.get_session(db, session_id, current_user.id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return await transcript_service.get_transcripts_by_session(db, session_id)


@router.get("/{session_id}/export", response_class=PlainTextResponse)
async def export_transcript(
    session_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    session = await session_service.get_session(db, session_id, current_user.id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    text = await transcript_service.export_transcript_text(db, session_id)
    return PlainTextResponse(
        content=text,
        headers={"Content-Disposition": f'attachment; filename="transcript_{session_id}.txt"'},
    )
