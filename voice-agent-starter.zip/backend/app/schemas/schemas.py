from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime
from app.models.transcript import SpeakerRole


# ─── Auth ────────────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    email: EmailStr
    username: str
    password: str
    full_name: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserResponse(BaseModel):
    id: int
    email: str
    username: str
    full_name: Optional[str]
    preferred_language: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse


# ─── Sessions ────────────────────────────────────────────────────────────────

class SessionCreate(BaseModel):
    title: Optional[str] = None
    language: str = "en"
    llm_provider: str = "ollama"
    llm_model: Optional[str] = None
    tts_provider: str = "edge"
    stt_provider: str = "whisper"


class SessionUpdate(BaseModel):
    title: Optional[str] = None
    is_active: Optional[bool] = None


class SessionResponse(BaseModel):
    id: int
    user_id: int
    title: Optional[str]
    language: str
    llm_provider: str
    llm_model: Optional[str]
    tts_provider: str
    stt_provider: str
    is_active: bool
    started_at: datetime
    ended_at: Optional[datetime]

    class Config:
        from_attributes = True


# ─── Transcripts ─────────────────────────────────────────────────────────────

class TranscriptCreate(BaseModel):
    session_id: int
    speaker: SpeakerRole
    text: str
    language: str = "en"
    confidence: Optional[float] = None
    audio_duration_ms: Optional[int] = None
    llm_provider: Optional[str] = None
    llm_model: Optional[str] = None


class TranscriptResponse(BaseModel):
    id: int
    session_id: int
    speaker: SpeakerRole
    text: str
    language: str
    confidence: Optional[float]
    audio_duration_ms: Optional[int]
    llm_provider: Optional[str]
    llm_model: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ─── WebSocket Messages ───────────────────────────────────────────────────────

class WSMessage(BaseModel):
    type: str   # "audio_chunk" | "text_input" | "ping" | "config"
    payload: Optional[dict] = None


class WSEvent(BaseModel):
    type: str   # "transcript" | "llm_response" | "tts_audio" | "error" | "pong" | "status"
    payload: Optional[dict] = None
