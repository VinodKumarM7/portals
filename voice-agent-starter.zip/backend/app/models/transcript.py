from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.db.database import Base


class SpeakerRole(str, enum.Enum):
    user = "user"
    assistant = "assistant"
    system = "system"


class Transcript(Base):
    __tablename__ = "transcripts"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("voice_sessions.id"), nullable=False)
    speaker = Column(Enum(SpeakerRole), nullable=False)
    text = Column(Text, nullable=False)
    language = Column(String, default="en")
    confidence = Column(Float, nullable=True)       # STT confidence score
    audio_duration_ms = Column(Integer, nullable=True)
    llm_provider = Column(String, nullable=True)    # which LLM generated this response
    llm_model = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    session = relationship("VoiceSession", back_populates="transcripts")
